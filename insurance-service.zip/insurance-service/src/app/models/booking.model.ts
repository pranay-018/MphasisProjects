export interface Booking {
  planId: number;
  planName: string;
  name: string;
  email: string;
  phone: string;        // ✅ ADDED
  cardNumber: string;
  city: string;
  paymentMode: string;
  age: number;
  premiumAmt: number;
  paymentFreq: string;
  validTill: string;
}
