export interface Plan {
    planId: number;
    planName: string;
    description: string;
    baseAmt: number;
    validity: number;
  }
  