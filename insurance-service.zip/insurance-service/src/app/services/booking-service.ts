import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Booking } from '../models/booking.model';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  private apiUrl = 'http://localhost:3333/bookings';

  constructor(private http: HttpClient) { }

  createBooking(booking: Booking) {
    return this.http.post(this.apiUrl, booking);
  }

  getBookingsByEmail(email: string) {
    return this.http.get<Booking[]>(
      `${this.apiUrl}?email=${email}`
    );
  }
}
