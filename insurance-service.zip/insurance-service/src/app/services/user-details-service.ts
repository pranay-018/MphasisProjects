import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UserDetailsService {
  userData: any = null;

  setUserDetails(data: any) {
    this.userData = data;
  }

  getUserDetails() {
    return this.userData;
  }

  hasUserDetails(): boolean {
    return this.userData !== null;
  }
}
