import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Plan } from '../models/plan.model';

@Injectable({
  providedIn: 'root',
})
export class PlansService {
  private apiUrl = 'http://localhost:3333';

  constructor(private http: HttpClient) {}

  getAllPlans() {
    return this.http.get<Plan[]>(`${this.apiUrl}/plans`);
  }
}
