import { Routes } from '@angular/router';

export const routes: Routes = [
    {
        path: '',
        pathMatch: 'full',
        redirectTo: 'insurance-service/home'
    },
    {
        path: 'insurance-service/home',
        loadComponent: () => import("./components/home/home")
            .then(m => m.Home)
    },
    {
        path: 'insurance-service/about',
        loadComponent: () => import("./components/about/about")
            .then(m => m.About)
    },

    {
        path: 'insurance-service/plans',
        loadComponent: () => import("./components/plans/plans")
            .then(m => m.Plans)
    },
    {
        path: 'insurance-service/user-details',
        loadComponent: () => import("./components/user-details/user-details")
            .then(m => m.UserDetails)
    }
    
];
