import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserDetailsService } from '../../services/user-details-service';
import { PlansService } from '../../services/plans-service';
import { CommonModule } from '@angular/common';
import { Plan } from '../../models/plan.model';

@Component({
  selector: 'app-plans',
  standalone:true,
  imports: [CommonModule],
  templateUrl: './plans.html',
  styleUrl: './plans.css',
})
export class Plans implements OnInit {

  plans: Plan[] = [];

  constructor(
    private userDetailsService: UserDetailsService,
    private plansService: PlansService,
    private router: Router
  ) { }
  ngOnInit(): void {


    // if (!this.userDetailsService.hasUserDetails()) {
    //   // User has NOT entered details → ask questions
    //   this.router.navigate(['/insurance-service/user-details']);
    //   return;
    // }

    this.plansService.getAllPlans().subscribe({
      next: (data) => {
        this.plans = data;
        console.log(this.plans);
      },
      error: () => {
        console.log('Error fetching plans');
      }
    });
  }
}
