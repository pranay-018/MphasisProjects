import { Component, OnInit, signal } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

import { Plan } from '../../models/plan.model';
import { Booking } from '../../models/booking.model';

import { PlansService } from '../../services/plans-service';
import { UserDetailsService } from '../../services/user-details-service';
import { BookingService } from '../../services/booking-service';

@Component({
  selector: 'app-plans',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './plans.html',
  styleUrls: ['./plans.css']
})
export class Plans implements OnInit {

  plans = signal<Plan[]>([]);
  selectedPlan = signal<Plan | null>(null);
  userBookings = signal<Booking[]>([]);
  calculatedPremium = signal<number>(0);

  constructor(
    private plansService: PlansService,
    private userDetailsService: UserDetailsService,
    private bookingService: BookingService,
    private router: Router
  ) {}

  ngOnInit(): void {

    const user = this.userDetailsService.getUserDetails();

    // 🔴 Force user details before plans
    if (!user || !user.name || !user.email) {
      this.router.navigate(['/insurance-service/user-details']);
      return;
    }

    // Fetch user bookings
    this.bookingService
      .getBookingsByEmail(user.email)
      .subscribe(bookings => {
        this.userBookings.set(bookings);
      });

    // Fetch plans
    this.plansService.getAllPlans().subscribe(data => {
      this.plans.set(data);
    });
  }

  // Calculate premium based on user details
  calculatePremium(plan: Plan): number {

    const user = this.userDetailsService.getUserDetails();
    let premium = plan.baseAmt;

    // AGE FACTOR
    if (user.age <= 25) {
      premium += 300;
    } else if (user.age <= 35) {
      premium += 600;
    } else if (user.age <= 45) {
      premium += 1000;
    } else {
      premium += 1500;
    }

    // INCOME FACTOR
    if (user.income <= 30000) {
      premium += 200;
    } else if (user.income <= 60000) {
      premium += 500;
    } else {
      premium += 800;
    }

    // HEALTH FACTOR
    if (user.healthIssue === 'yes') {
      premium += 1500;
    }

    return premium;
  }

  // Open popup & calculate premium
  openPopup(plan: Plan) {
    this.selectedPlan.set(plan);
    this.calculatedPremium.set(this.calculatePremium(plan));
  }

  closePopup() {
    this.selectedPlan.set(null);
  }

  buyNow() {
    const plan = this.selectedPlan();
    if (!plan) return;

    this.router.navigate(
      ['/insurance-service/payment'],
      {
        state: {
          plan: plan,
          premiumAmt: this.calculatedPremium()
        }
      }
    );
  }
}
