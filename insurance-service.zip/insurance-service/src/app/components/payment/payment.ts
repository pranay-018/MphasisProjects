import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { BookingService } from '../../services/booking-service';
import { UserDetailsService } from '../../services/user-details-service';
import { Booking } from '../../models/booking.model';

@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './payment.html'
})
export class Payment implements OnInit {

  // Form fields
  cardNumber = '';
  city = '';
  paymentMode = 'credit card';
  paymentFreq = 'yearly';

  // Data from Plans page
  selectedPlan: any;
  premiumAmt = 0;
  validTill = '';

  
  constructor(
    private bookingService: BookingService,
    private userDetailsService: UserDetailsService,
    private router: Router
  ) {}

  ngOnInit(): void {

    // 🔴 Ensure plan exists
    if (!history.state || !history.state.plan) {
      this.router.navigate(['/insurance-service/plans']);
      return;
    }

    // 🔴 Ensure user exists
    const user = this.userDetailsService.getUserDetails();
    if (!user) {
      this.router.navigate(['/insurance-service/user-details']);
      return;
    }

    // ✅ Read passed data
    this.selectedPlan = history.state.plan;
    this.premiumAmt = history.state.premiumAmt;
    this.validTill = this.calculateValidTill(this.selectedPlan.validity);

  }

  calculateValidTill(validityDays: number): string {
  const today = new Date();
  today.setDate(today.getDate() + validityDays);
  return today.toISOString().split('T')[0]; // yyyy-mm-dd
}


  submitPayment() {

  const user = this.userDetailsService.getUserDetails();
  if (!user || !this.selectedPlan) {
    this.router.navigate(['/insurance-service/user-details']);
    return;
  }

  const booking: Booking = {
    planId: this.selectedPlan.planId,
    planName: this.selectedPlan.planName,
    name: user.name,
    email: user.email,
    phone: user.phone, 
    cardNumber: this.cardNumber,
    city: this.city,
    paymentMode: this.paymentMode,
    age: user.age,
    premiumAmt: this.premiumAmt,
    paymentFreq: this.paymentFreq,
    validTill: this.validTill
  };

  this.bookingService.createBooking(booking).subscribe(() => {
    this.router.navigate(['/insurance-service/plans']);
  });
}

}
