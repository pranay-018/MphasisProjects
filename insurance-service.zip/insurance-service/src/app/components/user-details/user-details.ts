import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserDetailsService } from '../../services/user-details-service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-user-details',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './user-details.html',
  styleUrl: './user-details.css',
})
export class UserDetails {

  name = '';
  email = '';
  phone = '';       
  age!: number;
  income!: number;
  healthIssue: string = 'no';

  constructor(
    private router: Router,
    private userDetailsService: UserDetailsService
  ) {}

  submitDetails() {

    this.userDetailsService.setUserDetails({
      name: this.name,
      email: this.email,
      phone: this.phone,     
      age: this.age,
      income: this.income,
      healthIssue: this.healthIssue
    });

    this.router.navigate(['/insurance-service/plans']);
  }
}
