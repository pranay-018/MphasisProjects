package com.java.tax_calculation;

import java.util.Scanner;

//*************************TAX CALCULATION APPLICATION********************************* 
public class App {
	public static void main(String[] args) {
		System.out.println("+-----------------------------------------------------+");
		System.out.println("|       WELCOME TO TAX CALCULATION APPLICATION        |");
		System.out.println("+-----------------------------------------------------+");
		System.out.println("PLEASE LOGIN TO CONTINUE  -");
		Scanner sc = new Scanner(System.in);
		String userName = 
	}
}
