import { Component } from '@angular/core';

@Component({
  selector: 'app-plans',
  imports: [],
  templateUrl: './plans.component.html',
  styleUrl: './plans.component.css'
})
export class PlansComponent {

}
