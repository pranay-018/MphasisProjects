import { Component } from '@angular/core';

@Component({
  selector: 'app-plan-details',
  imports: [],
  templateUrl: './plan-details.component.html',
  styleUrl: './plan-details.component.css'
})
export class PlanDetailsComponent {

}
