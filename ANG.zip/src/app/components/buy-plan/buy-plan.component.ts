import { Component } from '@angular/core';

@Component({
  selector: 'app-buy-plan',
  imports: [],
  templateUrl: './buy-plan.component.html',
  styleUrl: './buy-plan.component.css'
})
export class BuyPlanComponent {

}
