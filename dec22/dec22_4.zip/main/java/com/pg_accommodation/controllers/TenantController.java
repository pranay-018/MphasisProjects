package com.pg_accommodation.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pg_accommodation.dtos.reponseDtos.TenantResponseDTO;
import com.pg_accommodation.dtos.requestDtos.TenantRequestDTO;
import com.pg_accommodation.services.TenantService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/tenants")
public class TenantController {
	@Autowired
	private TenantService tenantService;

	@PostMapping("/register")
	public ResponseEntity<TenantResponseDTO> registerTenant(@Valid @RequestBody TenantRequestDTO requestDTO) {

		TenantResponseDTO response = tenantService.registerTenant(requestDTO);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@GetMapping("/{id}")
	public ResponseEntity<TenantResponseDTO> getTenantById(@PathVariable Long id) {

		TenantResponseDTO response = tenantService.getTenantById(id);
		return ResponseEntity.ok(response);
	}

	@PutMapping("/{id}")
	public ResponseEntity<TenantResponseDTO> updateTenant(@PathVariable Long id,
			@Valid @RequestBody TenantRequestDTO requestDTO) {

		TenantResponseDTO response = tenantService.updateTenant(id, requestDTO);
		return ResponseEntity.ok(response);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteTenant(@PathVariable Long id) {

		tenantService.deleteTenant(id);
		return ResponseEntity.ok("Tenant deleted successfully");
	}
}