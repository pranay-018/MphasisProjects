package com.pg_accommodation.controllers;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.pg_accommodation.dtos.reponseDtos.OwnerResponseDTO;
import com.pg_accommodation.dtos.reponseDtos.PGAccommodationResponseDTO;
import com.pg_accommodation.dtos.requestDtos.PGAccommodationRequestDTO;
import com.pg_accommodation.services.PGAccommodationService;

import java.util.List;

@RestController
@RequestMapping("/pg")
public class PGAccommodationController {
	@Autowired
	private PGAccommodationService pgAccommodationService;

	@PostMapping("/add")
	public ResponseEntity<PGAccommodationResponseDTO> addPG(@Valid @RequestBody PGAccommodationRequestDTO requestDTO) {

		PGAccommodationResponseDTO response = pgAccommodationService.addPG(requestDTO);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@GetMapping("/details/{id}")
	public ResponseEntity<PGAccommodationResponseDTO> getPGById(@PathVariable Long id) {

		return ResponseEntity.ok(pgAccommodationService.getPGById(id));
	}
	
	@GetMapping("/owners/{city")
	public ResponseEntity<List<OwnerResponseDTO>> getOwnersByPlace(@PathVariable String city){
		return ResponseEntity.ok(pgAccommodationService.getOwnersByPlace(city));
	}

	@GetMapping("/city/{city}")
	public ResponseEntity<List<PGAccommodationResponseDTO>> getPGsByCity(@PathVariable String city) {

		return ResponseEntity.ok(pgAccommodationService.getPGsByCity(city));
	}

	@GetMapping("/locality/{locality}")
	public ResponseEntity<List<PGAccommodationResponseDTO>> getPGsByLocality(@PathVariable String locality) {

		return ResponseEntity.ok(pgAccommodationService.getPGsByLocality(locality));
	}

	@PutMapping("/{id}")
	public ResponseEntity<PGAccommodationResponseDTO> updatePG(@PathVariable Long id,
			@Valid @RequestBody PGAccommodationRequestDTO requestDTO) {

		return ResponseEntity.ok(pgAccommodationService.updatePG(id, requestDTO));
	}

	@PatchMapping("/status/{id}")
	public ResponseEntity<String> changeAvailabilityStatus(@PathVariable Long id) {

		pgAccommodationService.changeAvailabilityStatus(id);
		return ResponseEntity.ok("PG availability status updated");
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> deletePG(@PathVariable Long id) {

		pgAccommodationService.deletePG(id);
		return ResponseEntity.ok("PG deleted successfully");
	}
}