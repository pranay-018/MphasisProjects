package com.pg_accommodation.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.pg_accommodation.dtos.reponseDtos.OwnerResponseDTO;
import com.pg_accommodation.entities.PGAccommodation;
import com.pg_accommodation.enums.AvailabilityStatus;

import java.util.List;

@Repository
public interface PGAccommodationRepository extends JpaRepository<PGAccommodation, Long> {

	List<PGAccommodation> findByCityIgnoreCaseAndAvailabilityStatus(String city, AvailabilityStatus availabilityStatus);

	List<PGAccommodation> findByLocalityIgnoreCaseAndAvailabilityStatus(String locality,
			AvailabilityStatus availabilityStatus);

	List<PGAccommodation> findByOwnerOwnerId(Long ownerId);
	@Query(value = "select ")
	List<OwnerResponseDTO> findOwnersByCity(String city);
}
