package com.pg_accommodation.dtos.reponseDtos;

public class TenantResponseDTO {

	private Long tenantId;
	private String name;
	private String email;
	private String mobile;
	private int age;
	private String gender;

	public TenantResponseDTO(Long tenantId, String name, String email, String mobile, int age, String gender) {
		super();
		this.tenantId = tenantId;
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.age = age;
		this.gender = gender;
	}

	public Long getTenantId() {
		return tenantId;
	}

	public void setTenantId(Long tenantId) {
		this.tenantId = tenantId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "TenantResponseDTO{" + "tenantId=" + tenantId + ", name='" + name + '\'' + ", email='" + email + '\''
				+ ", mobile='" + mobile + '\'' + ", age=" + age + ", gender='" + gender + '\'' + '}';
	}

}
