package com.pg_accommodation.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pg_accommodation.dtos.reponseDtos.OwnerResponseDTO;
import com.pg_accommodation.dtos.requestDtos.OwnerRequestDTO;
import com.pg_accommodation.entities.Owner;
import com.pg_accommodation.exceptions.EmailAlreadyExisting;
import com.pg_accommodation.exceptions.MobileNumberAlreadyExists;
import com.pg_accommodation.exceptions.OwnerNotFound;
import com.pg_accommodation.repositories.OwnerRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OwnerServiceImpl implements OwnerService {
	@Autowired
	private OwnerRepository ownerRepository;

	@Override
	public OwnerResponseDTO registerOwner(OwnerRequestDTO dto) {

		if (ownerRepository.existsByEmail(dto.getEmail())) {
			throw new EmailAlreadyExisting("Email already registered");
		}

		if (ownerRepository.existsByMobile(dto.getMobile())) {
			throw new MobileNumberAlreadyExists("Mobile number already registered");
		}

		Owner owner = new Owner();
		owner.setName(dto.getName());
		owner.setEmail(dto.getEmail());
		owner.setMobile(dto.getMobile());
		owner.setAge(dto.getAge());

		Owner savedOwner = ownerRepository.save(owner);
		return mapToResponse(savedOwner);
	}

	@Override
	public OwnerResponseDTO getOwnerById(Long ownerId) {

		Owner owner = ownerRepository.findById(ownerId).orElseThrow(() -> new OwnerNotFound("Owner not found"));

		return mapToResponse(owner);
	}

	@Override
	public List<OwnerResponseDTO> getAllOwners() {

		return ownerRepository.findAll().stream().map(this::mapToResponse).collect(Collectors.toList());
	}

	@Override
	public OwnerResponseDTO updateOwner(Long ownerId, OwnerRequestDTO dto) {

		Owner owner = ownerRepository.findById(ownerId).orElseThrow(() -> new OwnerNotFound("Owner not found"));

		owner.setName(dto.getName());
		owner.setEmail(dto.getEmail());
		owner.setMobile(dto.getMobile());
		owner.setAge(dto.getAge());

		Owner updatedOwner = ownerRepository.save(owner);
		return mapToResponse(updatedOwner);
	}

	@Override
	public void deleteOwner(Long ownerId) {

		Owner owner = ownerRepository.findById(ownerId).orElseThrow(() -> new OwnerNotFound("Owner not found"));

		ownerRepository.delete(owner);
	}

	private OwnerResponseDTO mapToResponse(Owner owner) {

		return new OwnerResponseDTO(owner.getOwnerId(), owner.getName(), owner.getEmail(), owner.getMobile(),
				owner.getAge());
	}
}
