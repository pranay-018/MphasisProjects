package com.pg_accommodation.services;

import java.util.List;

import com.pg_accommodation.dtos.reponseDtos.OwnerResponseDTO;
import com.pg_accommodation.dtos.reponseDtos.PGAccommodationResponseDTO;
import com.pg_accommodation.dtos.requestDtos.PGAccommodationRequestDTO;

public interface PGAccommodationService {

	PGAccommodationResponseDTO addPG(PGAccommodationRequestDTO dto);

	PGAccommodationResponseDTO getPGById(Long id);

	List<PGAccommodationResponseDTO> getPGsByCity(String city);

	List<PGAccommodationResponseDTO> getPGsByLocality(String locality);

	PGAccommodationResponseDTO updatePG(Long id, PGAccommodationRequestDTO dto);

	void changeAvailabilityStatus(Long id);

	void deletePG(Long id);
	
	List<OwnerResponseDTO> getOwnersByPlace(String city);
}
