package com.quiz.servlets.admin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;

import com.quiz.db.DBConnection;

public class ViewHighScoresByQuizServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Map<String, String>> scores = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();

            String sql =
                "SELECT q.name AS quiz, MAX(uqs.score) AS high_score, " +
                "COUNT(DISTINCT uqs.user_id) AS attempts " +
                "FROM user_quiz_score uqs " +
                "JOIN quiz q ON uqs.quiz_id = q.id " +
                "GROUP BY q.id";

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String, String> s = new HashMap<>();
                s.put("quiz", rs.getString("quiz"));
                s.put("highScore", rs.getString("high_score"));
                s.put("attempts", rs.getString("attempts"));
                scores.add(s);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("scores", scores);
        request.getRequestDispatcher("/admin_views/viewHighScoresByQuiz.jsp")
               .forward(request, response);
    }
}
