package com.quiz.servlets.admin;

import com.quiz.db.DBConnection;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

public class ViewQuizAttemptStatsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Map<String, String>> stats = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();
            String sql =
                "SELECT q.name AS quiz_name, " +
                "COUNT(DISTINCT uqs.user_id) AS users_attempted " +
                "FROM quiz q " +
                "LEFT JOIN user_quiz_score uqs ON q.id = uqs.quiz_id " +
                "GROUP BY q.id, q.name";

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String, String> m = new HashMap<>();
                m.put("quiz", rs.getString("quiz_name"));
                m.put("count", rs.getString("users_attempted"));
                stats.add(m);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("stats", stats);
        request.getRequestDispatcher("/admin_views/viewQuizAttempts.jsp")
               .forward(request, response);
    }
}
