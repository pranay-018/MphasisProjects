package com.quiz.servlets.user;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

import com.quiz.db.DBConnection;
import com.quiz.model.Question;

public class SubmitQuizServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        ArrayList<Question> questions =
                (ArrayList<Question>) session.getAttribute("quizQuestions");

        int quizId = (int) session.getAttribute("quizId");
        int userId = (int) session.getAttribute("userId");

        int score = 0;

        for (Question q : questions) {
            String userAns = request.getParameter("answer_" + q.getId());
            if (userAns != null && userAns.equals(q.getCorrect())) {
                score++;
            }
        }

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO user_quiz_score (user_id, quiz_id, score, total_questions) VALUES (?, ?, ?, ?)"
            );

            ps.setInt(1, userId);
            ps.setInt(2, quizId);
            ps.setInt(3, score);
            ps.setInt(4, questions.size());

            ps.executeUpdate();

            session.setAttribute("score", score);
            session.setAttribute("total", questions.size());

            response.sendRedirect(request.getContextPath() + "/user_views/result.jsp");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
