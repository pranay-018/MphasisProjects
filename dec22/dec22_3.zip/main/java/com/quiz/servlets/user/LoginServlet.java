package com.quiz.servlets.user;

import com.quiz.db.DBConnection;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;

public class LoginServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String email = request.getParameter("email");
		String pass = request.getParameter("password");

		try {
			Connection con = DBConnection.getConnection();

			PreparedStatement ps = con.prepareStatement("SELECT * FROM users WHERE email=? AND password=?");
			ps.setString(1, email);
			ps.setString(2, pass);

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				HttpSession session = request.getSession();
				session.setAttribute("userId", rs.getInt("id"));
				session.setAttribute("userName", rs.getString("name"));

				response.sendRedirect(request.getContextPath() + "/user_views/home.jsp");

			} else {
				request.setAttribute("error", "Invalid Login Credentials!");
				request.getRequestDispatcher("/user_views/login.jsp").forward(request, response);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
