package com.quiz.filters;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class AdminAuthFilter implements Filter {

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {

		 HttpServletRequest request = (HttpServletRequest) req;
	        HttpServletResponse response = (HttpServletResponse) res;

	        HttpSession session = request.getSession(false);

	        boolean loggedIn = (session != null && session.getAttribute("adminId") != null);
	        boolean loginPage = request.getRequestURI().endsWith("adminLogin.jsp");

	        if (loggedIn || loginPage) {
	            chain.doFilter(req, res);
	        } else {
	            response.sendRedirect(request.getContextPath() + "/admin_views/adminLogin.jsp");
	        }
	}
}
