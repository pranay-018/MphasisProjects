package com.pg_accommodation.exceptions;

public class MobileNumberAlreadyExists extends RuntimeException {
	public MobileNumberAlreadyExists(String message) {
		super(message);
	}
}