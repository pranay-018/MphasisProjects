package com.pg_accommodation.entities;

import com.pg_accommodation.enums.AvailabilityStatus;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;

@Entity
@Table(name = "pg_accommodations")
public class PGAccommodation {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long pgId;

	@NotBlank(message = "Registration number is required")
	private String registrationNumber;

	@Positive(message = "Built-up area must be positive")
	private double builtUpArea;

	@Positive(message = "Rent amount must be greater than zero")
	private double rentAmount;

	@NotBlank(message = "City is required")
	private String city;

	@NotBlank(message = "Locality is required")
	private String locality;

	@NotNull(message = "Availability status is required")
	@Enumerated(EnumType.STRING)
	private AvailabilityStatus availabilityStatus;

	@PositiveOrZero(message = "Visitor count cannot be negative")
	private int visitorCount;

	@ManyToOne
	@JoinColumn(name = "owner_id")
	@NotNull(message = "Owner is required")
	private Owner owner;

	public PGAccommodation(Long pgId, @NotBlank(message = "Registration number is required") String registrationNumber,
			@Positive(message = "Built-up area must be positive") double builtUpArea,
			@Positive(message = "Rent amount must be greater than zero") double rentAmount,
			@NotBlank(message = "City is required") String city,
			@NotBlank(message = "Locality is required") String locality,
			@NotNull(message = "Availability status is required") AvailabilityStatus availabilityStatus,
			@PositiveOrZero(message = "Visitor count cannot be negative") int visitorCount,
			@NotNull(message = "Owner is required") Owner owner) {
		super();
		this.pgId = pgId;
		this.registrationNumber = registrationNumber;
		this.builtUpArea = builtUpArea;
		this.rentAmount = rentAmount;
		this.city = city;
		this.locality = locality;
		this.availabilityStatus = availabilityStatus;
		this.visitorCount = visitorCount;
		this.owner = owner;
	}

	public PGAccommodation() {

	}

	public Long getPgId() {
		return pgId;
	}

	public void setPgId(Long pgId) {
		this.pgId = pgId;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public double getBuiltUpArea() {
		return builtUpArea;
	}

	public void setBuiltUpArea(double builtUpArea) {
		this.builtUpArea = builtUpArea;
	}

	public double getRentAmount() {
		return rentAmount;
	}

	public void setRentAmount(double rentAmount) {
		this.rentAmount = rentAmount;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public AvailabilityStatus getAvailabilityStatus() {
		return availabilityStatus;
	}

	public void setAvailabilityStatus(AvailabilityStatus availabilityStatus) {
		this.availabilityStatus = availabilityStatus;
	}

	public int getVisitorCount() {
		return visitorCount;
	}

	public void setVisitorCount(int visitorCount) {
		this.visitorCount = visitorCount;
	}

	public Owner getOwner() {
		return owner;
	}

	public void setOwner(Owner owner) {
		this.owner = owner;
	}
}