package com.pg_accommodation.entities;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name = "owners")
public class Owner {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long ownerId;

	@NotBlank(message = "Owner name is required")
	private String name;

	@Email(message = "Invalid email format")
	@NotBlank(message = "Email is required")
	private String email;

	@Pattern(regexp = "^[6-9][0-9]{9}$", message = "Mobile number must be 10 digits")
	private String mobile;

	@Min(value = 18, message = "Owner must be at least 18 years old")
	private int age;

	@OneToMany(mappedBy = "owner", cascade = CascadeType.ALL)
	private List<PGAccommodation> pgPlaces;

	public Owner() {
		super();
	}

	public Owner(Long ownerId, @NotBlank(message = "Owner name is required") String name,
			@Email(message = "Invalid email format") @NotBlank(message = "Email is required") String email,
			@Pattern(regexp = "^[6-9][0-9]{9}$", message = "Mobile number must be 10 digits") String mobile,
			@Min(value = 18, message = "Owner must be at least 18 years old") int age, List<PGAccommodation> pgPlaces) {
		super();
		this.ownerId = ownerId;
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.age = age;
		this.pgPlaces = pgPlaces;
	}

	public Long getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(Long ownerId) {
		this.ownerId = ownerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public List<PGAccommodation> getPgPlaces() {
		return pgPlaces;
	}

	public void setPgPlaces(List<PGAccommodation> pgPlaces) {
		this.pgPlaces = pgPlaces;
	}
}