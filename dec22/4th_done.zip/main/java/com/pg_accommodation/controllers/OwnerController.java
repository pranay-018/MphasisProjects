package com.pg_accommodation.controllers;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.pg_accommodation.dtos.reponseDtos.OwnerResponseDTO;
import com.pg_accommodation.dtos.requestDtos.OwnerRequestDTO;
import com.pg_accommodation.services.OwnerService;

import java.util.List;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/owners")
@Tag(name = "Owner APIs", description = "Owner related operations")
public class OwnerController {

    @Autowired
    private OwnerService ownerService;

    @Operation(summary = "Register a new owner")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Owner registered successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid owner data")
    })
    @PostMapping("/register")
    public ResponseEntity<OwnerResponseDTO> registerOwner(
            @Valid @RequestBody OwnerRequestDTO requestDTO) {

        OwnerResponseDTO response = ownerService.registerOwner(requestDTO);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @Operation(summary = "Get owner by ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Owner found"),
        @ApiResponse(responseCode = "404", description = "Owner not found")
    })
    @GetMapping("/{id}")
    public ResponseEntity<OwnerResponseDTO> getOwnerById(@PathVariable Long id) {
        return ResponseEntity.ok(ownerService.getOwnerById(id));
    }

    @Operation(summary = "Get all owners")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Owners retrieved successfully")
    })
    @GetMapping
    public ResponseEntity<List<OwnerResponseDTO>> getAllOwners() {
        return ResponseEntity.ok(ownerService.getAllOwners());
    }

    @Operation(summary = "Update owner details")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Owner updated successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid owner data"),
        @ApiResponse(responseCode = "404", description = "Owner not found")
    })
    @PutMapping("/{id}")
    public ResponseEntity<OwnerResponseDTO> updateOwner(
            @PathVariable Long id,
            @Valid @RequestBody OwnerRequestDTO requestDTO) {

        return ResponseEntity.ok(ownerService.updateOwner(id, requestDTO));
    }

    @Operation(summary = "Delete owner")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Owner deleted successfully"),
        @ApiResponse(responseCode = "404", description = "Owner not found")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteOwner(@PathVariable Long id) {

        ownerService.deleteOwner(id);
        return ResponseEntity.ok("Owner deleted successfully");
    }
}
