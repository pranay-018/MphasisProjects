package com.pg_accommodation.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.pg_accommodation.dtos.reponseDtos.OwnerResponseDTO;
import com.pg_accommodation.dtos.reponseDtos.PGAccommodationResponseDTO;
import com.pg_accommodation.dtos.reponseDtos.TenantResponseDTO;
import com.pg_accommodation.services.AdminService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/admin")
@Tag(name = "Admin APIs", description = "Administrative operations")
public class AdminController {

	@Autowired
	private AdminService adminService;



	@Operation(summary = "Get all tenants")
	@ApiResponses({ @ApiResponse(responseCode = "200", description = "Tenants retrieved successfully") })
	@GetMapping("/tenants")
	public ResponseEntity<List<TenantResponseDTO>> getAllTenants() {
		return ResponseEntity.ok(adminService.getAllTenants());
	}



	@Operation(summary = "Get all owners")
	@ApiResponses({ @ApiResponse(responseCode = "200", description = "Owners retrieved successfully") })
	@GetMapping("/owners")
	public ResponseEntity<List<OwnerResponseDTO>> getAllOwners() {
		return ResponseEntity.ok(adminService.getAllOwners());
	}



	@Operation(summary = "Get all PG accommodations")
	@ApiResponses({ @ApiResponse(responseCode = "200", description = "PGs retrieved successfully") })
	@GetMapping("/pgs")
	public ResponseEntity<List<PGAccommodationResponseDTO>> getAllPGs() {
		return ResponseEntity.ok(adminService.getAllPGs());
	}

	

	@Operation(summary = "Delete tenant by ID")
	@ApiResponses({ @ApiResponse(responseCode = "200", description = "Tenant deleted successfully"),
			@ApiResponse(responseCode = "404", description = "Tenant not found") })
	@DeleteMapping("/tenant/{id}")
	public ResponseEntity<String> deleteTenant(@PathVariable Long id) {
		adminService.deleteTenant(id);
		return ResponseEntity.ok("Tenant deleted by Admin");
	}

	

	@Operation(summary = "Delete owner by ID")
	@ApiResponses({ @ApiResponse(responseCode = "200", description = "Owner deleted successfully"),
			@ApiResponse(responseCode = "404", description = "Owner not found") })
	@DeleteMapping("/owner/{id}")
	public ResponseEntity<String> deleteOwner(@PathVariable Long id) {
		adminService.deleteOwner(id);
		return ResponseEntity.ok("Owner deleted by Admin");
	}

	
	@Operation(summary = "Delete PG by ID")
	@ApiResponses({ @ApiResponse(responseCode = "200", description = "PG deleted successfully"),
			@ApiResponse(responseCode = "404", description = "PG not found") })
	@DeleteMapping("/pg/{id}")
	public ResponseEntity<String> deletePG(@PathVariable Long id) {
		adminService.deletePG(id);
		return ResponseEntity.ok("PG deleted by Admin");
	}
}
