package com.pg_accommodation.controllers;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.pg_accommodation.dtos.reponseDtos.OwnerResponseDTO;
import com.pg_accommodation.dtos.reponseDtos.PGAccommodationResponseDTO;
import com.pg_accommodation.dtos.requestDtos.PGAccommodationRequestDTO;
import com.pg_accommodation.services.OwnerService;
import com.pg_accommodation.services.PGAccommodationService;

import java.util.List;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/pg")
@Tag(name = "PG Accommodation APIs", description = "PG accommodation related operations")
public class PGAccommodationController {

    @Autowired
    private PGAccommodationService pgAccommodationService;

    @Autowired
    private OwnerService ownerService;

    @Operation(summary = "Add a new PG accommodation")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "PG added successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid PG data")
    })
    @PostMapping("/add")
    public ResponseEntity<PGAccommodationResponseDTO> addPG(
            @Valid @RequestBody PGAccommodationRequestDTO requestDTO) {

        PGAccommodationResponseDTO response = pgAccommodationService.addPG(requestDTO);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @Operation(summary = "Get PG details by ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "PG found"),
        @ApiResponse(responseCode = "404", description = "PG not found")
    })
    @GetMapping("/details/{id}")
    public ResponseEntity<PGAccommodationResponseDTO> getPGById(@PathVariable Long id) {

        return ResponseEntity.ok(pgAccommodationService.getPGById(id));
    }

    @Operation(summary = "Get owner details by city")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Owner details retrieved successfully")
    })
    @GetMapping("/owners/{city}")
    public ResponseEntity<List<OwnerResponseDTO>> getOwnersByCity(
            @PathVariable String city) {

        return ResponseEntity.ok(ownerService.getOwnerDetailsByCity(city));
    }

    @Operation(summary = "Get available PGs by city")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "PGs retrieved successfully")
    })
    @GetMapping("/city/{city}")
    public ResponseEntity<List<PGAccommodationResponseDTO>> getPGsByCity(
            @PathVariable String city) {

        return ResponseEntity.ok(pgAccommodationService.getPGsByCity(city));
    }

    @Operation(summary = "Get available PGs by locality")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "PGs retrieved successfully")
    })
    @GetMapping("/locality/{locality}")
    public ResponseEntity<List<PGAccommodationResponseDTO>> getPGsByLocality(
            @PathVariable String locality) {

        return ResponseEntity.ok(pgAccommodationService.getPGsByLocality(locality));
    }

    @Operation(summary = "Update PG accommodation details")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "PG updated successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid PG data"),
        @ApiResponse(responseCode = "404", description = "PG not found")
    })
    @PutMapping("/{id}")
    public ResponseEntity<PGAccommodationResponseDTO> updatePG(
            @PathVariable Long id,
            @Valid @RequestBody PGAccommodationRequestDTO requestDTO) {

        return ResponseEntity.ok(pgAccommodationService.updatePG(id, requestDTO));
    }

    @Operation(summary = "Change PG availability status")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "PG status updated successfully"),
        @ApiResponse(responseCode = "404", description = "PG not found")
    })
    @PatchMapping("/status/{id}")
    public ResponseEntity<String> changeAvailabilityStatus(@PathVariable Long id) {

        pgAccommodationService.changeAvailabilityStatus(id);
        return ResponseEntity.ok("PG availability status updated");
    }

    @Operation(summary = "Delete PG accommodation")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "PG deleted successfully"),
        @ApiResponse(responseCode = "404", description = "PG not found")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletePG(@PathVariable Long id) {

        pgAccommodationService.deletePG(id);
        return ResponseEntity.ok("PG deleted successfully");
    }
}
