package com.pg_accommodation.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pg_accommodation.dtos.reponseDtos.TenantResponseDTO;
import com.pg_accommodation.dtos.requestDtos.TenantRequestDTO;
import com.pg_accommodation.entities.Tenant;
import com.pg_accommodation.exceptions.EmailAlreadyExisting;
import com.pg_accommodation.exceptions.TenantNotFound;
import com.pg_accommodation.repositories.TenantRepository;

@Service
public class TenantServiceImpl implements TenantService {
	@Autowired
	private TenantRepository tenantRepository;

	@Override
	public TenantResponseDTO registerTenant(TenantRequestDTO dto) {

		if (tenantRepository.existsByEmail(dto.getEmail())) {
			throw new EmailAlreadyExisting("Email already registered");
		}

		Tenant tenant = new Tenant();
		tenant.setName(dto.getName());
		tenant.setEmail(dto.getEmail());
		tenant.setMobileNumber(dto.getMobile());
		tenant.setAge(dto.getAge());
		tenant.setGender(dto.getGender());

		Tenant saved = tenantRepository.save(tenant);
		return mapToResponse(saved);
	}

	@Override
	public TenantResponseDTO getTenantById(Long id) {

		Tenant tenant = tenantRepository.findById(id).orElseThrow(() -> new TenantNotFound("Tenant not found"));

		return mapToResponse(tenant);
	}

	@Override
	public TenantResponseDTO updateTenant(Long id, TenantRequestDTO dto) {

		Tenant tenant = tenantRepository.findById(id).orElseThrow(() -> new TenantNotFound("Tenant not found"));

		tenant.setName(dto.getName());
		tenant.setMobileNumber(dto.getMobile());
		tenant.setAge(dto.getAge());
		tenant.setGender(dto.getGender());

		Tenant updated = tenantRepository.save(tenant);
		return mapToResponse(updated);
	}

	@Override
	public void deleteTenant(Long id) {

		Tenant tenant = tenantRepository.findById(id).orElseThrow(() -> new TenantNotFound("Tenant not found"));

		tenantRepository.delete(tenant);
	}

	private TenantResponseDTO mapToResponse(Tenant tenant) {
		return new TenantResponseDTO(tenant.getTenantId(), tenant.getName(), tenant.getEmail(),
				tenant.getMobileNumber(), tenant.getAge(), tenant.getGender());
	}
}