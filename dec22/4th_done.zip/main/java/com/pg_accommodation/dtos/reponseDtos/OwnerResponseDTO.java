package com.pg_accommodation.dtos.reponseDtos;

public class OwnerResponseDTO {

    private Long ownerId;
    private String name;
    private String email;
    private String mobile;
    private int age;
	public OwnerResponseDTO(Long ownerId, String name, String email, String mobile, int age) {
		super();
		this.ownerId = ownerId;
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.age = age;
	}
	public Long getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(Long ownerId) {
		this.ownerId = ownerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
}
