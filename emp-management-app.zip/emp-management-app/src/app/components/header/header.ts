import { Component } from '@angular/core';
import { Navcomp } from "../navcomp/navcomp";

@Component({
  selector: 'app-header',
  imports: [Navcomp],
  templateUrl: './header.html',
  styleUrl: './header.css',
})
export class Header {

}
