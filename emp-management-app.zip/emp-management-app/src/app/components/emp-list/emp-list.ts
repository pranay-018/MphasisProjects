import { Component, signal } from '@angular/core';
import { Employee } from '../../models/employee.model';
import { Router, RouterLink } from "@angular/router";
import { Empservice } from '../../services/empservice';

@Component({
  selector: 'app-emp-list',
  imports: [RouterLink],
  templateUrl: './emp-list.html',
  styleUrl: './emp-list.css',
})
export class EmpList {

  empList = signal<Employee[]>([]);
  constructor(private router: Router, private empService: Empservice) { }
  ngOnInit(): void {
    this.empService.findAll().subscribe(
      (data)=>{
        console.log("Employees from DB .json",data);
        this.empList.set(data);
      },
      (error)=>{
        console.error("error in fectching data : ",error)
      }
    );
  }
  delete(empId: number) {
   
    this.router.navigate(['/emp/list'])
  }
}
