import { Component } from '@angular/core';
import { Form, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Employee } from '../../models/employee.model';
import { ActivatedRoute, Router } from '@angular/router';
import { Empservice } from '../../services/empservice';

@Component({
  selector: 'app-emp-update',
  imports: [FormsModule,ReactiveFormsModule],
  templateUrl: './emp-update.html',
  styleUrl: './emp-update.css',
})
export class EmpUpdate {
  employee: any = {};
  empList: Employee[] = [];
  empId?: any;
  empForm: FormGroup

  constructor(private route: ActivatedRoute, public fb: FormBuilder,private router:Router,private service:Empservice) {
    this.empForm = this.fb.group({
      eid: [{ value: 0, disabled: true }],
      ename: ['', [Validators.required, Validators.minLength(3)]],
      desg: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")]],
      mobile: ['', [Validators.required, Validators.pattern("[6789][0-9]{9}")]],
      salary: [0, [Validators.required]],
      dept: ['', [Validators.required]]
    })
  }



  ngOnInit(): void {
    this.empList = [new Employee(234, "pranay", "trainee", 'pranay@gmail.com', '9874561238', 56000, 'IT'),
    new Employee(452, "prani", "Manager", 'pranireddy@gmail.com', '9974561238', 96000, 'SALES'),
    new Employee(973, "latha", "senior HR", 'padmalatha@gmail.com', '9874561298', 76000, 'HR'),
    ]
    this.empId = Number(this.route.snapshot.paramMap.get('eid'));
    this.employee = this.empList.find(e=>e.eid===this.empId);
    this.empForm.patchValue({
      eid:this.employee.eid,
      ename:this.employee.ename,
      desg:this.employee.desg,
      email:this.employee.email,
      mobile:this.employee.mobile,
      salary:this.employee?.salary,
      dept:this.employee?.dept,
    })
  }



    update() {
        this.service.update(this.empId,this.employee).subscribe(()=>{
          console.log("emp updated")
        })
        this.router.navigate(['/emp/list'])
  }
}
