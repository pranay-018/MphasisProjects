import { Component, signal } from '@angular/core';
import { Employee } from '../../models/employee.model';
import { ActivatedRoute, Router } from '@angular/router';
import { Empservice } from '../../services/empservice';


@Component({
  selector: 'app-emp-info',
  imports: [],
  templateUrl: './emp-info.html',
  styleUrl: './emp-info.css',
})
export class EmpInfo {
     empId!:number;
     emp = signal<Employee | null>(null);
     constructor(private empService:Empservice,private route:ActivatedRoute,private router:Router){}
      ngOnInit(): void {
      
        this.empId = Number(this.route.snapshot.paramMap.get('eid'))
        this.findByID(this.empId)

      }

      findByID(eid: number): void {
        this.empService.findById(eid).subscribe({
          next: empp => this.emp.set(empp),  
          error: err => {
            console.error('Employee not found', err);
            this.emp.set(null);
          }
        });
      }
      back(){
        this.router.navigate(['/emp/list'])
      }
}
