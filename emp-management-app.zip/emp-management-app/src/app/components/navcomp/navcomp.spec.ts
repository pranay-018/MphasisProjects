import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Navcomp } from './navcomp';

describe('Navcomp', () => {
  let component: Navcomp;
  let fixture: ComponentFixture<Navcomp>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Navcomp]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Navcomp);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
