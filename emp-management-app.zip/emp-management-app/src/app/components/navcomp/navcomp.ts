import { Component } from '@angular/core';
import { RouterLink } from "@angular/router";

@Component({
  selector: 'app-navcomp',
  imports: [RouterLink],
  templateUrl: './navcomp.html',
  styleUrl: './navcomp.css',
})
export class Navcomp {

}
