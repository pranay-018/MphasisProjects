import { Component } from '@angular/core';
import { Employee } from '../../models/employee.model';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Empservice } from '../../services/empservice';

@Component({
  selector: 'app-add-emp',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './add-emp.html',
  styleUrl: './add-emp.css',
})
export class AddEmp {
  employee: any = {};
  empList: Employee[] = [];
  constructor(private router:Router,private empService:Empservice){}
  ngOnInit(): void {
    this.empList = [new Employee(234, "pranay", "trainee", 'pranay@gmail.com', '9874561238', 56000, 'IT'),
    new Employee(452, "prani", "Manager", 'pranireddy@gmail.com', '9974561238', 96000, 'SALES'),
    new Employee(973, "latha", "senior HR", 'padmalatha@gmail.com', '9874561298', 76000, 'HR'),
    ]
  }

  onSubmit(empForm: any) {
    if (empForm.invalid) return
    let emp = empForm.value
    this.employee = new Employee(emp.eid, emp.ename, emp.desg, emp.email, emp.mobile, emp.salary, emp.dept)
    console.log(this.employee)
    this.empList.push(this.employee)
    this.empList.forEach(e=>console.log(e))
    alert("employee Added successfully");
    this.empService.save(emp).subscribe(()=>{
      console.log(this.employee)
    })
    this.router.navigate(['/emp/list'])

  }

}
