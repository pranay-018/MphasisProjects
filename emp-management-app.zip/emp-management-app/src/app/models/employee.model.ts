export class Employee {
    // eid!: number;
    // ename!: string; // nno need these decalartions if we use the 'public in contrcutors
    // desg!: string;
    // email!: string;
    // mobile!: string
    // salary!: number;
    // dept!: string;
    constructor(public eid: number,public ename: string,public desg: string,public email: string,public mobile: string,public salary: number,public dept: string) {
        this.eid = eid
        this.ename = ename;
        this.desg = desg;
        this.email = email;
        this.mobile = mobile;
        this.salary = salary;
        this.dept = dept;
    }
}
