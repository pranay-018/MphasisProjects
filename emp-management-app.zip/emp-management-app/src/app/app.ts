import { Component, signal } from '@angular/core';
import { RouterModule, RouterOutlet } from '@angular/router';
import { AddEmp } from './components/add-emp/add-emp';
import { EmpList } from './components/emp-list/emp-list';
import { EmpInfo } from "./components/emp-info/emp-info";
import { EmpUpdate } from './components/emp-update/emp-update';
import { Header } from "./components/header/header";
import { Main } from "./components/main/main";
import { Footer } from "./components/footer/footer";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, AddEmp, EmpList, EmpInfo, RouterModule, EmpUpdate, Header, Main, Footer],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('emp-management-app');
}
