import { Routes } from '@angular/router';

export const routes: Routes = [
    {
        path : '',
        pathMatch:'full',
        redirectTo:'emp/list'
    },
    {
        path:'emp/add',
        loadComponent:()=>import ("./components/add-emp/add-emp")
        .then(m=>m.AddEmp)
    },
    {
        path:'emp/list',
        loadComponent:()=>import ("./components/emp-list/emp-list")
        .then(m=>m.EmpList)
    },
    {
        path:'emp/info/:eid',
        loadComponent:()=>import ("./components/emp-info/emp-info")
        .then(m=>m.EmpInfo)
    },
    {
        path:"emp/update/:eid",
        loadComponent:()=>import("./components/emp-update/emp-update")
        .then(m=>m.EmpUpdate)
    }
];
