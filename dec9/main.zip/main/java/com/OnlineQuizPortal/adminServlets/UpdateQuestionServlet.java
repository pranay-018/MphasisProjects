package com.OnlineQuizPortal.adminServlets;

import java.io.IOException;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/UpdateQuestionServlet")
public class UpdateQuestionServlet extends HttpServlet {

	private static final String URL = "jdbc:mysql://localhost:3306/online_quiz";
	private static final String USER = "root";
	private static final String PASSWORD = "Pranay@18";

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int id = Integer.parseInt(request.getParameter("id"));
		String q = request.getParameter("question");
		String a = request.getParameter("optA");
		String b = request.getParameter("optB");
		String c = request.getParameter("optC");
		String d = request.getParameter("optD");
		String correct = request.getParameter("correct");

		String sql = "UPDATE questions SET question_text=?, option_a=?, option_b=?, option_c=?, option_d=?, correct_option=? WHERE id=?";

		try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
				PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setString(1, q);
			ps.setString(2, a);
			ps.setString(3, b);
			ps.setString(4, c);
			ps.setString(5, d);
			ps.setString(6, correct);
			ps.setInt(7, id);

			ps.executeUpdate();

			response.sendRedirect("admin_views/view-questions.jsp");

		} catch (Exception e) {
			e.printStackTrace();
			response.getWriter().println("Error updating question!");
		}
	}
}
