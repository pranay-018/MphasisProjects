package com.OnlineQuizPortal.adminServlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpSession;

@WebServlet("/AdminLogin")
public class AdminLogin extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database constants (direct JDBC)
    private static final String URL = 
        "jdbc:mysql://localhost:3306/online_quiz";
    private static final String USER = "root";
    private static final String PASSWORD = "Pranay@18";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");   // load MySQL driver once
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String adminUser = request.getParameter("username");
        String adminPass = request.getParameter("password");

        String sql = "SELECT * FROM admin WHERE username=? AND password=?";

        try (
            // Direct JDBC connection here — no DBConnection class
            Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
            PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, adminUser);
            ps.setString(2, adminPass);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // Successful login
                HttpSession session = request.getSession();
                session.setAttribute("adminUser", adminUser);

                response.sendRedirect(request.getContextPath() + "/AdminDashBoardServlet");
            } else {
                // Failed login
                request.setAttribute("error", "Invalid username or password");
                RequestDispatcher rd = request.getRequestDispatcher("admin_views/admin-login.jsp");
                rd.forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error occurred!");
            request.getRequestDispatcher("admin_views/admin-login.jsp").forward(request, response);
        }
    }
}
