package com.OnlineQuizPortal.adminServlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.RequestDispatcher;

@WebServlet("/ChangePasswordServlet")
public class ChangePasswordServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private static final String URL = "jdbc:mysql://localhost:3306/online_quiz";
	private static final String USER = "root";
	private static final String PASSWORD = "Pranay@18";

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		String admin = (String) session.getAttribute("adminUser");

		if (admin == null) {
			response.sendRedirect("admin_views/admin-login.jsp");
			return;
		}

		String oldPass = request.getParameter("oldPassword");
		String newPass = request.getParameter("newPassword");

		String checkSQL = "SELECT * FROM admin WHERE username=? AND password=?";
		String updateSQL = "UPDATE admin SET password=? WHERE username=?";

		try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {

			// 1️⃣ Check old password
			PreparedStatement ps1 = con.prepareStatement(checkSQL);
			ps1.setString(1, admin);
			ps1.setString(2, oldPass);

			ResultSet rs = ps1.executeQuery();

			if (!rs.next()) {
				request.setAttribute("msg", "Incorrect current password!");
				RequestDispatcher rd = request.getRequestDispatcher("admin_views/change-password.jsp");
				rd.forward(request, response);
				return;
			}

			// 2️⃣ Update new password
			PreparedStatement ps2 = con.prepareStatement(updateSQL);
			ps2.setString(1, newPass);
			ps2.setString(2, admin);

			ps2.executeUpdate();

			request.setAttribute("msg", "Password changed successfully!");
			RequestDispatcher rd = request.getRequestDispatcher("admin_views/change-password.jsp");
			rd.forward(request, response);

		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "Error updating password!");
			request.getRequestDispatcher("admin_views/change-password.jsp").forward(request, response);
		}
	}
}
