package com.OnlineQuizPortal.adminServlets;

import java.io.IOException;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/ModifyQuestionServlet")
public class ModifyQuestionServlet extends HttpServlet {

	private static final String URL = "jdbc:mysql://localhost:3306/online_quiz";
	private static final String USER = "root";
	private static final String PASSWORD = "Pranay@18";

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int id = Integer.parseInt(request.getParameter("id"));

		try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {

			PreparedStatement ps = con.prepareStatement("SELECT * FROM questions WHERE id=?");
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				request.setAttribute("qid", id);
				request.setAttribute("question", rs.getString("question_text"));
				request.setAttribute("optA", rs.getString("option_a"));
				request.setAttribute("optB", rs.getString("option_b"));
				request.setAttribute("optC", rs.getString("option_c"));
				request.setAttribute("optD", rs.getString("option_d"));
				request.setAttribute("correct", rs.getString("correct"));
			}

			request.getRequestDispatcher("admin_views/modify-question.jsp").forward(request, response);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
