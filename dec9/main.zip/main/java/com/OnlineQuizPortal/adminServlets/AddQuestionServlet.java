package com.OnlineQuizPortal.adminServlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AddQuestionServlet")
public class AddQuestionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String URL =
            "jdbc:mysql://localhost:3306/online_quiz?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "Pranay@18";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String quizId = request.getParameter("quizId");
        String q = request.getParameter("question");
        String a = request.getParameter("optA");
        String b = request.getParameter("optB");
        String c = request.getParameter("optC");
        String d = request.getParameter("optD");
        String correct = request.getParameter("correct");

        String insertQuestionSQL =
                "INSERT INTO questions(question_text, option_a, option_b, option_c, option_d, correct_option) VALUES (?,?,?,?,?,?)";

        String mapSQL =
                "INSERT INTO quiz_questions(quiz_id, question_id) VALUES(?, ?)";

        try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {

            // 1️⃣ Insert Question into questions table
            PreparedStatement ps1 = con.prepareStatement(insertQuestionSQL, PreparedStatement.RETURN_GENERATED_KEYS);
            ps1.setString(1, q);
            ps1.setString(2, a);
            ps1.setString(3, b);
            ps1.setString(4, c);
            ps1.setString(5, d);
            ps1.setString(6, correct);

            ps1.executeUpdate();

            // 2️⃣ Fetch generated question_id
            ResultSet rs = ps1.getGeneratedKeys();
            int questionId = 0;
            if (rs.next()) {
                questionId = rs.getInt(1);
            }

            // 3️⃣ Insert into quiz_questions table
            PreparedStatement ps2 = con.prepareStatement(mapSQL);
            ps2.setInt(1, Integer.parseInt(quizId));
            ps2.setInt(2, questionId);
            ps2.executeUpdate();

            // 4️⃣ Redirect
            response.sendRedirect("admin_views/admin-dashboard.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error while adding question!");
        }
    }
}
