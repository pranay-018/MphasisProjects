package com.OnlineQuizPortal.adminServlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DeleteQuestionServlet")
public class DeleteQuestionServlet extends HttpServlet {

	private static final String URL = "jdbc:mysql://localhost:3306/online_quiz";
	private static final String USER = "root";
	private static final String PASSWORD = "Pranay@18";

	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int questionId = Integer.parseInt(request.getParameter("id"));

		String deleteMapping = "DELETE FROM quiz_questions WHERE question_id=?";
		String deleteQuestion = "DELETE FROM questions WHERE id=?";

		try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {

			PreparedStatement ps1 = con.prepareStatement(deleteMapping);
			ps1.setInt(1, questionId);
			ps1.executeUpdate();

			PreparedStatement ps2 = con.prepareStatement(deleteQuestion);
			ps2.setInt(1, questionId);
			ps2.executeUpdate();

			response.sendRedirect("admin_views/view-questions.jsp");

		} catch (Exception e) {
			e.printStackTrace();
			response.getWriter().println("Error deleting question!");
		}
	}
}
