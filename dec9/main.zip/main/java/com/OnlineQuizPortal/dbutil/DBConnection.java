package com.OnlineQuizPortal.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	private static String className;
	private static String username;
	private static String password;
	private static String dbUrl;

	public static void setCrenditials(String class_name, String user_name, String pass_word, String db_url) {
		className = class_name;
		username = user_name;
		password = pass_word;
		dbUrl = db_url;
	}

	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		return DriverManager.getConnection("jdbc:mysql://localhost:3306/online_quiz", username, password);

	}
}
