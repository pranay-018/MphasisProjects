package com.pg_accommodation.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoggingAspect.class);

	@Before("execution(* com.pg_accommodation.*.*(..))")
	public void beforeEachMethod(JoinPoint joinPoint) {
		LOGGER.info("entering method : {}", joinPoint.getSignature());
	}

	@After("execution(* com.springboot.*.*(..))")
	public void afterEachMethod(JoinPoint joinPoint) {
		LOGGER.info(joinPoint.getSignature().getName());
	}

	@AfterReturning("execution(* com.springboot.*.*(..))")
	public void afterReturningEachMethod(JoinPoint joinPoint) {
		LOGGER.info("exiting  method : {}", joinPoint.getSignature());
	}

	@AfterThrowing(pointcut = "execution(* com.springboot.*.*(..))", throwing = "ex")
	public void afterExceptionThrown(JoinPoint joinPoint, Exception ex) {
		LOGGER.error("Service layer Exception :{},message={}", joinPoint.getSignature(), ex.getMessage());
	}
}
