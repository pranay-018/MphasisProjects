package com.pg_accommodation.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import com.pg_accommodation.entities.Admin;

public interface AdminRepository extends JpaRepository<Admin, Long> {
}