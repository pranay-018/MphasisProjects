package com.pg_accommodation.services;

import com.pg_accommodation.dtos.reponseDtos.TenantResponseDTO;
import com.pg_accommodation.dtos.requestDtos.TenantRequestDTO;

public interface TenantService {
	TenantResponseDTO registerTenant(TenantRequestDTO dto);

	TenantResponseDTO getTenantById(Long id);

	TenantResponseDTO updateTenant(Long id, TenantRequestDTO dto);

	void deleteTenant(Long id);
}
