package com.pg_accommodation.services;

import java.util.List;

import org.jspecify.annotations.Nullable;

import com.pg_accommodation.dtos.reponseDtos.OwnerResponseDTO;
import com.pg_accommodation.dtos.requestDtos.OwnerRequestDTO;

public interface OwnerService {
	OwnerResponseDTO registerOwner(OwnerRequestDTO ownerRequestDTO);

	OwnerResponseDTO getOwnerById(Long ownerId);

	List<OwnerResponseDTO> getAllOwners();

	OwnerResponseDTO updateOwner(Long ownerId, OwnerRequestDTO ownerRequestDTO);

	void deleteOwner(Long ownerId);

	List<OwnerResponseDTO> getOwnerDetailsByCity(String city);

	OwnerResponseDTO getOwnerDetailsByPgId(Long pgId);
}
