package com.pg_accommodation.services;

import java.util.List;

import com.pg_accommodation.dtos.reponseDtos.OwnerResponseDTO;
import com.pg_accommodation.dtos.reponseDtos.PGAccommodationResponseDTO;
import com.pg_accommodation.dtos.reponseDtos.TenantResponseDTO;

public interface AdminService {

    // View all data
    List<TenantResponseDTO> getAllTenants();
    List<OwnerResponseDTO> getAllOwners();
    List<PGAccommodationResponseDTO> getAllPGs();

    // Delete operations
    void deleteTenant(Long tenantId);
    void deleteOwner(Long ownerId);
    void deletePG(Long pgId);
}
