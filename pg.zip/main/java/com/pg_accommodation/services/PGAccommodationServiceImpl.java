package com.pg_accommodation.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pg_accommodation.dtos.reponseDtos.OwnerResponseDTO;
import com.pg_accommodation.dtos.reponseDtos.PGAccommodationResponseDTO;
import com.pg_accommodation.dtos.requestDtos.PGAccommodationRequestDTO;
import com.pg_accommodation.entities.Owner;
import com.pg_accommodation.entities.PGAccommodation;
import com.pg_accommodation.enums.AvailabilityStatus;
import com.pg_accommodation.exceptions.OwnerNotFound;
import com.pg_accommodation.exceptions.PGNotFound;
import com.pg_accommodation.repositories.OwnerRepository;
import com.pg_accommodation.repositories.PGAccommodationRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PGAccommodationServiceImpl implements PGAccommodationService {
	@Autowired
	private PGAccommodationRepository pgAccommodationRepository;
	@Autowired
	private OwnerRepository ownerRepository;

	@Override
	public PGAccommodationResponseDTO addPG(PGAccommodationRequestDTO dto) {

		Owner owner = ownerRepository.findById(dto.getOwnerId())
				.orElseThrow(() -> new OwnerNotFound("Owner not found"));

		PGAccommodation pg = new PGAccommodation();
		pg.setRegistrationNumber(dto.getRegistrationNumber());
		pg.setBuiltUpArea(dto.getBuiltUpArea());
		pg.setRentAmount(dto.getRentAmount());
		pg.setCity(dto.getCity());
		pg.setLocality(dto.getLocality());
		pg.setAvailabilityStatus(AvailabilityStatus.AVAILABLE);
		pg.setVisitorCount(0);
		pg.setOwner(owner);

		return mapToResponse(pgAccommodationRepository.save(pg));
	}

	@Override
	public PGAccommodationResponseDTO getPGById(Long pgId) {

		PGAccommodation pg = pgAccommodationRepository.findById(pgId)
				.orElseThrow(() -> new PGNotFound("PG Accommodation not found"));

		pg.setVisitorCount(pg.getVisitorCount() + 1);
		pgAccommodationRepository.save(pg);

		return mapToResponse(pg);
	}

	@Override
	public List<PGAccommodationResponseDTO> getPGsByCity(String city) {

		return pgAccommodationRepository.findByCityIgnoreCaseAndAvailabilityStatus(city, AvailabilityStatus.AVAILABLE)
				.stream().map(this::mapToResponse).collect(Collectors.toList());
	}

	@Override
	public List<PGAccommodationResponseDTO> getPGsByLocality(String locality) {

		return pgAccommodationRepository
				.findByLocalityIgnoreCaseAndAvailabilityStatus(locality, AvailabilityStatus.AVAILABLE).stream()
				.map(this::mapToResponse).collect(Collectors.toList());
	}

	@Override
	public PGAccommodationResponseDTO updatePG(Long pgId, PGAccommodationRequestDTO dto) {

		PGAccommodation pg = pgAccommodationRepository.findById(pgId)
				.orElseThrow(() -> new PGNotFound("PG Accommodation not found"));

		pg.setRegistrationNumber(dto.getRegistrationNumber());
		pg.setBuiltUpArea(dto.getBuiltUpArea());
		pg.setRentAmount(dto.getRentAmount());
		pg.setCity(dto.getCity());
		pg.setLocality(dto.getLocality());

		return mapToResponse(pgAccommodationRepository.save(pg));
	}

	@Override
	public void changeAvailabilityStatus(Long pgId) {

		PGAccommodation pg = pgAccommodationRepository.findById(pgId)
				.orElseThrow(() -> new PGNotFound("PG Accommodation not found"));

		pg.setAvailabilityStatus(
				pg.getAvailabilityStatus() == AvailabilityStatus.AVAILABLE ? AvailabilityStatus.OCCUPIED
						: AvailabilityStatus.AVAILABLE);

		pgAccommodationRepository.save(pg);
	}

	@Override
	public void deletePG(Long pgId) {

		PGAccommodation pg = pgAccommodationRepository.findById(pgId)
				.orElseThrow(() -> new PGNotFound("PG Accommodation not found"));

		pgAccommodationRepository.delete(pg);
	}

	private PGAccommodationResponseDTO mapToResponse(PGAccommodation pg) {

		return new PGAccommodationResponseDTO(pg.getPgId(), pg.getRegistrationNumber(), pg.getBuiltUpArea(),
				pg.getRentAmount(), pg.getCity(), pg.getLocality(), pg.getAvailabilityStatus().name(),
				pg.getVisitorCount());
	}

	@Override
	public List<PGAccommodationResponseDTO> getPGsByOwnerId(Long ownerId) {

		List<PGAccommodation> pgList = pgAccommodationRepository.findByOwnerOwnerId(ownerId);

		return pgList.stream()
				.map(pg -> new PGAccommodationResponseDTO(pg.getPgId(), pg.getRegistrationNumber(), pg.getBuiltUpArea(),
						pg.getRentAmount(), pg.getCity(), pg.getLocality(), pg.getAvailabilityStatus().name(),
						pg.getVisitorCount()))
				.collect(Collectors.toList());
	}
}
