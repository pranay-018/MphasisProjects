package com.pg_accommodation.exceptions;

public class OwnerNotFound extends RuntimeException {
	public OwnerNotFound(String message) {
		super(message);
	}
}