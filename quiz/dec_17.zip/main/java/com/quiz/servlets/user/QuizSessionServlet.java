package com.quiz.servlets.user;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

import com.quiz.db.DBConnection;
import com.quiz.model.Question;

public class QuizSessionServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int quizId = Integer.parseInt(request.getParameter("quizId"));
		HttpSession session = request.getSession();

		try {
			Connection con = DBConnection.getConnection();

			PreparedStatement ps = con.prepareStatement("SELECT q.* FROM questions q "
					+ "JOIN quiz_questions qq ON q.id = qq.question_id " + "WHERE qq.quiz_id = ?");
			ps.setInt(1, quizId);
			ResultSet rs = ps.executeQuery();

			ArrayList<Question> questions = new ArrayList<>();

			while (rs.next()) {
				questions.add(new Question(rs.getInt("id"), rs.getString("question_text"), rs.getString("option_a"),
						rs.getString("option_b"), rs.getString("option_c"), rs.getString("option_d"),
						rs.getString("correct_option")));
			}
			if (questions.size() == 0) {
			    session.setAttribute("quizError", "No questions available for this quiz.");
			    response.sendRedirect("home.jsp");
			    return;
			}

			session.setAttribute("quizId", quizId);
			session.setAttribute("quizQuestions", questions);
			session.setAttribute("currentIndex", 0);
			session.setAttribute("userAnswers", new HashMap<Integer, String>());

			 response.sendRedirect(request.getContextPath() + "/user_views/startQuiz.jsp");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
