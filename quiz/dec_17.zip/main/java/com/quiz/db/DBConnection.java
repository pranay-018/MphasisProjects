package com.quiz.db;

import java.sql.*;
import jakarta.servlet.*;

public class DBConnection implements ServletContextListener {

    private static Connection connection;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        try {
            ServletContext ctx = sce.getServletContext();

            String url = ctx.getInitParameter("DB_URL");
            String user = ctx.getInitParameter("DB_USER");
            String pass = ctx.getInitParameter("DB_PASS");

            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(url, user, pass);

            System.out.println("DB Connected Successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() {
        return connection;
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        try {
            if (connection != null)
                connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
