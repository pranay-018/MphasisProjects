package com.quiz.servlets.admin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class AdminLogoutServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		if (session != null) {
			session.invalidate(); // destroy admin session
		}

		response.sendRedirect("admin_views/adminLogin.jsp"); // redirect to admin login
	}
}
