package com.quiz.filters;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class UserAuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        HttpSession session = req.getSession(false);
        String uri = req.getRequestURI();
        System.out.println("user filter invoked");

        // Allow public pages
        if (uri.endsWith("login.jsp") ||
            uri.endsWith("register.jsp") ||
            uri.endsWith("/login") ||
            uri.endsWith("/register") ||
            uri.endsWith("index.jsp")) {

            chain.doFilter(request, response);
            return;
        }

        // Check user session
        if (session != null && session.getAttribute("userId") != null) {
            chain.doFilter(request, response);
        } else {
            res.sendRedirect(req.getContextPath() + "/login.jsp");
        }
    }
}
