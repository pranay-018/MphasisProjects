package com.quiz.servlets.admin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import com.quiz.db.DBConnection;

public class AddQuestionServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        int quizId = Integer.parseInt(req.getParameter("quizId"));
        String q = req.getParameter("question");
        String a = req.getParameter("a");
        String b = req.getParameter("b");
        String c = req.getParameter("c");
        String d = req.getParameter("d");
        String correct = req.getParameter("correct");

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO questions(question_text, option_a, option_b, option_c, option_d, correct_option) VALUES(?,?,?,?,?,?)",
                Statement.RETURN_GENERATED_KEYS
            );

            ps.setString(1, q);
            ps.setString(2, a);
            ps.setString(3, b);
            ps.setString(4, c);
            ps.setString(5, d);
            ps.setString(6, correct);

            ps.executeUpdate();

            ResultSet keys = ps.getGeneratedKeys();
            keys.next();
            int questionId = keys.getInt(1);

            PreparedStatement link = con.prepareStatement(
                "INSERT INTO quiz_questions(quiz_id, question_id) VALUES (?, ?)"
            );
            link.setInt(1, quizId);
            link.setInt(2, questionId);
            link.executeUpdate();

            res.sendRedirect(req.getContextPath() + "/admin_views/viewQuestions.jsp");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
