package com.quiz.servlets.admin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import com.quiz.db.DBConnection;

public class AddQuizServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String quizName = request.getParameter("quizName");

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("INSERT INTO quiz(name) VALUES(?)");
            ps.setString(1, quizName);
            ps.executeUpdate();

            response.sendRedirect("viewQuizzes.jsp");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
