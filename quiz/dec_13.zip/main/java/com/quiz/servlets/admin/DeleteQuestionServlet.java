package com.quiz.servlets.admin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import com.quiz.db.DBConnection;

public class DeleteQuestionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        int questionId = Integer.parseInt(req.getParameter("id"));

        try {
            Connection con = DBConnection.getConnection();

            // 1️⃣ Delete mapping first
            PreparedStatement ps1 = con.prepareStatement(
                "DELETE FROM quiz_questions WHERE question_id=?"
            );
            ps1.setInt(1, questionId);
            ps1.executeUpdate();

            // 2️⃣ Delete question
            PreparedStatement ps2 = con.prepareStatement(
                "DELETE FROM questions WHERE id=?"
            );
            ps2.setInt(1, questionId);
            ps2.executeUpdate();

            res.sendRedirect("viewQuestions.jsp");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
