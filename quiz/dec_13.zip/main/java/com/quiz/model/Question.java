package com.quiz.model;

public class Question {
	private int id;
	private String text;
	private String a;
	private String b;
	private String c;
	private String d;
	private String correct;

	public Question(int id, String text, String a, String b, String c, String d, String correct) {
		this.id = id;
		this.text = text;
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
		this.correct = correct;
	}

	public int getId() {
		return id;
	}

	public String getText() {
		return text;
	}

	public String getA() {
		return a;
	}

	public String getB() {
		return b;
	}

	public String getC() {
		return c;
	}

	public String getD() {
		return d;
	}

	public String getCorrect() {
		return correct;
	}
}
