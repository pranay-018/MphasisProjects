package com.project.exceptions;

public class DataNotFound extends Exception {

	public DataNotFound() {

	}

	public DataNotFound(String message) {
		super(message);

	}

}
