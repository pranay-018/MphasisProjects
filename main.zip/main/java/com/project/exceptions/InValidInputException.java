package com.project.exceptions;

public class InValidInputException extends Exception {

	public InValidInputException() {

	}

	public InValidInputException(String message) {
		super(message);
	}
}