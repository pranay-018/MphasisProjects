
package com.project.exceptions;

public class InValidCredentials extends Exception {

	public InValidCredentials() {
	}

	public InValidCredentials(String message) {
		super(message);
	}

}
