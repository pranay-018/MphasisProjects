package com.project.taxcalculator;

import com.project.interfaces.TaxPayement;
import com.project.entities.Property;

public class PropertyTaxCalculation implements TaxPayement {
	@Override
	public double calculateTax(Object object) {
		Property property = (Property) object;
		double tax = 0.0;
		if (property.isInCity()) {
			tax = (double) (property.getBuiltUpArea() * property.getLandAge() * property.getLandBaseValue())
					+ (property.getBuiltUpArea()) / (double) 2;
		} else {
			tax = (double) (property.getBuiltUpArea() * property.getLandAge() * property.getLandBaseValue());
		}
		return tax;

	}

}
