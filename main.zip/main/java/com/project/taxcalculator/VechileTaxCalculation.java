package com.project.taxcalculator;

import com.project.interfaces.TaxPayement;
import com.project.entities.Property;
import com.project.entities.Vehicle;
import com.project.enums.FuelType;

public class VechileTaxCalculation implements TaxPayement {
	@Override
	public double calculateTax(Object object) {
		Vehicle vehicle = (Vehicle)object;
		double tax = 0.0;
		if (vehicle.getFuelType() == FuelType.PETROL) {
			tax = vehicle.getMaxVelocity() + vehicle.getCapacity() + (double) (0.10 * vehicle.getCost());
		} else if (vehicle.getFuelType() == FuelType.DIESEL) {
			tax = vehicle.getMaxVelocity() + vehicle.getCapacity() + (double) (0.11 * vehicle.getCost());
		} else {
			if (vehicle.getFuelType() == FuelType.PETROL) {
				tax = vehicle.getMaxVelocity() + vehicle.getCapacity() + (double) (0.12 * vehicle.getCost());
			}
		}
		return tax;

	}

}
