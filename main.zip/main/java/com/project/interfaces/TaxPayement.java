
package com.project.interfaces;

public interface TaxPayement {
	public  double calculateTax(Object o);
}
