
package com.project.interfaces;

public interface TaxPayement {
	public void calculateTax();
}
