package com.project.services;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.project.entities.Vehicle;
import com.project.enums.FuelType;
import com.project.exceptions.DataNotFound;
import com.project.exceptions.InValidInputException;
import com.project.tax_calculation.Menu;
import com.project.taxcalculator.VechileTaxCalculation;

public class VechileService {

	public VechileService() {

	}

	public static void vechileDetails(List<Vehicle> vehicles) {
		Scanner sc = new Scanner(System.in);
		int option = 0;
		do {
			try {
				Menu.displayVechileOptions();
				option = sc.nextInt();
				switch (option) {
				case 1:
					Vehicle vehicle = addVechile();
					if (vehicle != null) {
						vehicles.add(vehicle);
					}
					break;
				case 2:
					if (vehicles.size() > 0) {
						displayVechileProperties(vehicles);
						System.out.print("enter the Vechile Registration Number of vechile  to calculate Tax - ");
						int vechileID = sc.nextInt();
						Vehicle v = calulateVechiletax(vechileID, vehicles);
						if (v != null)
							System.out.println(" vechile tax for registration number - " + " is  " + v.getTax());
						else
							throw new DataNotFound("No data found with Vechile Registration");
					} else {
						System.out.println("No vechiles found");
					}
					break;
				case 3:
					displayVechileProperties(vehicles);
					break;
				case 4:
					System.out.println("back to main menu");
					return;
				default:
					System.out.println("please select correct option");
					break;
				}
			} catch (InputMismatchException inputMismatchException) {
				System.out.println("Invalid option , please enter the valid format data");
				sc.nextLine();
				continue;
			} catch (DataNotFound e) {
				System.out.println(e.getMessage());
				sc.nextLine();
				continue;

			}
		} while (option != 4);
	}

	private static Vehicle calulateVechiletax(int vechileID, List<Vehicle> vehicles) {
		Vehicle vehicle = SearchVechile(vehicles, vechileID);
		if (vehicle != null) {
			vehicle.setTax(new VechileTaxCalculation().calculateTax(vehicle));
			return vehicle;
		}
		return null;
	}

	private static Vehicle SearchVechile(List<Vehicle> vehicles, int vechileID) {
		for (Vehicle vehicle : vehicles) {
			if (vehicle.getRegistrationNumber() == vechileID) {
				return vehicle;
			}
		}
		return null;
	}

	private static void displayVechileProperties(List<Vehicle> vehicles) {
		if (vehicles.size() == 0) {
			System.out.println("No vechiles found");
			return;
		}
		System.out.println(
				"+----------------------------------------------------------------------------------------------------------------------+");

		// Header row
		System.out.printf(" %-18s  %-15s  %-15s  %-15s  %-15s  %-15s  %-15s \n", "REGISTRATION NO.", "BRAND",
				"MAX. VELOCITY", "NO. OF SEATS", "VEHICLE TYPE", "PURCHASE COST", "VEHICLE TAX");

		// Middle border
		System.out.println(
				"+----------------------------------------------------------------------------------------------------------------------+");

		// Data rows
		for (Vehicle v : vehicles) {

			System.out.printf(" %-18d  %-15s  %-15d  %-15d  %-15s  %-15.2f  %-15.2f \n", v.getRegistrationNumber(),
					v.getBrandName(), v.getMaxVelocity(), v.getCapacity(), v.getFuelType().name(), v.getCost(),
					v.getTax());
		}

		// Bottom border
		System.out.println(
				"+----------------------------------------------------------------------------------------------------------------------+");
		return;

	}

	private static Vehicle addVechile() {
		System.out.println("Enter the Vechile details : ".toUpperCase());
		try {
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter the 4 digit Registration Number  : ");
			String regNo = sc.nextLine().trim();

			if (!regNo.matches("\\d{4}")) {
				throw new InValidInputException("Registration number must be 4 digits and in valid format.");
			}

			if (regNo.equals("0000")) {
				throw new InValidInputException("Registration number cannot be 0000.");
			}
			int registrationNumber = Integer.parseInt(regNo);
			if (registrationNumber < 0) {
				throw new InValidInputException("Registration number cannot be negative.");
			}
			System.out.print("Enter the Brand of Vechile: ");
			String brand = sc.nextLine();
			if (brand == null)
				throw new InValidInputException("please enter the valid brand Name");
			System.out.print("Enter the cost of vechile : ");
			int cost = sc.nextInt();
			if (cost <= 0 || cost < 50000 || cost > 10000000)
				throw new InValidInputException("cost must be between 5000 and 1000000");
			System.out.print("Enter the maximum velocity of vechile : ");
			int maxVelocity = sc.nextInt();
			if (maxVelocity <= 0 || maxVelocity < 120 || maxVelocity > 300)
				throw new InValidInputException("speed must be between 120 and 300");
			System.out.print("Enter the capacity  vechile : ");
			int capacity = sc.nextInt();
			if (capacity < 2 || capacity > 50)
				throw new InValidInputException("Capacity must be between 2 and 50");
			System.out.println("Choose the type of fuel : ");
			System.out.println("1.PETROL DRIVEN");
			System.out.println("2.DEISEL DRIVEN");
			System.out.println("3.CNG/LPG Driven");
			int option = 0;
			option = sc.nextInt();
			FuelType fuelType;
			switch (option) {
			case 1:
				fuelType = FuelType.PETROL;
				break;
			case 2:
				fuelType = FuelType.DIESEL;
				break;
			case 3:
				fuelType = FuelType.CNG_LPG;
				break;

			default:
				throw new InValidInputException("please select the appropriate option : ");

			}
			return new Vehicle(registrationNumber, brand, cost, maxVelocity, capacity, fuelType);
		} catch (InputMismatchException inputMismatchException) {
			System.out.println("Invalid data , please enter the valid format data");
			return null;
		} catch (InValidInputException invalidException) {
			System.out.println(invalidException.getMessage());
			return null;
		}
	}

}