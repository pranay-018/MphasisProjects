package com.project.enums;

public enum FuelType {
	PETROL,DIESEL,CNG_LPG
}