package com.project.enums;

public enum FuelType {
	PETROL,DIESEL,GAS
}