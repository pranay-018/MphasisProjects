abstract class Account {
    accno: string
    accName: string
    ifsc: string

    constructor(accno: string, accName: string, ifsc: string) {
        this.accno = accno;
        this.accName = accName;
        this.ifsc = ifsc;
    }
}


class SavingAccount extends Account{
    balance:number
    constructor(balance:number,accNo:string,accName:string,ifsc:string){
        super(accNo,accName,ifsc)
        this.balance = balance;
      
    }
}


let sa : SavingAccount = new SavingAccount(56000,"61845132","pranay","ICIC006963");
console.log(sa);