// tupls are fixed size

let person:[number,string]=[156,"pranay"] // single 

let persons:[number,string][]=[[1234,"pranay"],[456,"prani"],[896,"vicky"]];// multiple 
console.log(person)
console.log(persons);




let arr = new Array<number>(5).fill(0)

console.log(arr)

let mynums : [number,number] = [12,56] as const // can't add the elements (we can use readonly aslo) \
let nums = Object.freeze([23,56]) // can be modify

let mynumsArray:number[] = [12,34,556]

mynumsArray.push(50)
console.log(mynums)
console.log(mynumsArray)

