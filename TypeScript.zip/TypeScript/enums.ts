enum Status {
    PENDING=10, ACTIVE=56, APPROVED=45, REJECTED=20
}


let txStatus:Status=Status.PENDING
console.log(txStatus)
txStatus = Status.ACTIVE
if(txStatus===Status.ACTIVE){
    console.log("active")
}
else{
    console.log("pending")
}