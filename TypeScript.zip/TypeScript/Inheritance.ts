class Person {
    constructor(public name: string, public id: number) {

    }
    sayHello() {
        console.log("hello " + this.name)
    }
}

class Student extends Person {
    constructor(public name: string, public id: number, public course: string) {
        super(name, id)
    }
    getInfo() {
        console.log(this.name + "  " + this.id + "   registered into " + this.course)
    }
}

let s: Student = new Student("pranay", 414, "java")
s.sayHello();
s.getInfo();


interface User {
    email: string
    pwd: string
    getCredentials(): void;
}


class Employee implements User {
    constructor(public email: string, public pwd: string) {
        this.email = email;
        this.pwd = pwd;
    }
    getCredentials(): void {
        console.log("email " + this.email + " password : " + this.pwd)
    }
}


let e: Employee = new Employee("pranay@gmail.com", "pranay@18")
console.log(e)
e.getCredentials();


class Teacher extends Person  implements User {
    constructor(public name: string, public id: number, public course: string, public email: string, public pwd: string){
        super(name,id)
    }
    getCredentials(): void {
        console.log("email " + this.email + " password : " + this.pwd)
    }
    getInfo() {
        console.log(this.name + "  " + this.id + "   registered into " + this.course)
    }
}

let t:Teacher=new Teacher("latha",5658,"HR","lath@gmail.com","latha@123")
t.getInfo();
t.getCredentials();


