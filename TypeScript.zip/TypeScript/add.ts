let a = 56
console.log(a)
console.log(typeof a) // type = number
// a = "pranay" -->error let cannot be changed wihtin a block 'let is block scoped  

{
    let b = 67;
    b = 98; // can be changed within the scope

    console.log(b)
}


{
    const d = 94;
    // d = 79;  --> cannot be changed but let can be changed
    console.log(d)
}

// console.log(b) --> get error let cannot be used outside the block

{
    var c = 47;
    console.log(c)
}

console.log(c); //--> var can be used outside the scope aslo


a = 45;
 let s = 56
 console.log(a+s)

