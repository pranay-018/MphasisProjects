function sayHello<T>(t:T):void{
    console.log(t)
}

sayHello("pranay")

let p={
    name:"pranay",
    id:896
}

sayHello(p);


function greet(name :string):string{
    return "hello,  "+name;
}

sayHello(greet("pranay")); // we can pass function also

let myName="Pranay Reddy"
sayHello((myName:string)=>{
    return myName.toUpperCase();
})


console.log("generic class")
class Container<T>{
    constructor(public t:T){
    }
    getValue():T{
        return this.t;
    }

}
let numContainer:Container<Number> = new Container(56);
let strContainer:Container<string> = new Container("pranay");
let objContainer:Container<Object> = new Container(p);
console.log(numContainer.getValue());
console.log(strContainer.getValue());
console.log(objContainer.getValue());