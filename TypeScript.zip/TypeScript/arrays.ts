let names = ["pranay","prani","latha","ramesh"]
console.log(names)

console.log(typeof names)  //-> object ts and js are object based language rather than OOPS
