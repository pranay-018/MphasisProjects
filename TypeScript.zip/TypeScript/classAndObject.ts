let person={  // '{' is used for object representation
    name:"pranay", // maintain key : value
    id:"123"
}
console.log(person)

class Student{
    name="pranay" // here for class it uses key=value
    id= 1236 
}

// creating obj for the Student
let s:Student=new Student() 
console.log(s)        

// constructor

class Student1{
    sname:String; // declare
    sid:number; // must be assigned in constructor 
    sage!:number // for not assigning or using in constrcutor -> it implies it is undefined . so we need to assign where we wants
    constructor(){
        this.sname = "pranay" // assign in consructors
        this.sid = 1455
    }
}

console.log(typeof Student1)

let s1:Student1 = new Student1();
console.log( typeof s1)
console.log(s1)

s1.sname = "latha"
console.log(s1);

const s2:Student1 = new Student1();
s2.sname = "padma"; // we can change the members of s2 
console.log(s2);

// s2:Student = new Student() // --> we can't modify the s2 since it is const



class Student3{
    sname:String
    sid:number
    constructor(sname:String,sid:number){
        this.sname  = sname
        this.sid = sid

    }
}


let stuArray:Student3[] = [
    new Student3("pranay",236),new Student3("prani",566),
];

console.log(stuArray);

stuArray.forEach(student=>{
    console.log(student.sname.toUpperCase())
}
)
// using for loop

for(let i=0;i<stuArray.length;i++){
    // console.log(stuArray[i].sname.toUpperCase() + " " + stuArray[i].sid) // error since we not used ? . so the value can be undefined to retrict that undefined we use '?'
    console.log(stuArray[i]?.sname.toUpperCase() + " " + stuArray[i]?.sid)
}

console.log("nodemon working")
console.log("hello")