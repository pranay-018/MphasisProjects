package com.pg_accommodation.controllers;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.pg_accommodation.dtos.reponseDtos.OwnerResponseDTO;
import com.pg_accommodation.dtos.requestDtos.OwnerRequestDTO;
import com.pg_accommodation.services.OwnerService;

import java.util.List;

@RestController
@RequestMapping("/owners")
public class OwnerController {
	@Autowired
	private OwnerService ownerService;

	// CREATE - Register Owner
	@PostMapping("/register")
	public ResponseEntity<OwnerResponseDTO> registerOwner(@Valid @RequestBody OwnerRequestDTO requestDTO) {

		OwnerResponseDTO response = ownerService.registerOwner(requestDTO);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	// READ - Get Owner by ID
	@GetMapping("/{id}")
	public ResponseEntity<OwnerResponseDTO> getOwnerById(@PathVariable Long id) {
		return ResponseEntity.ok(ownerService.getOwnerById(id));
	}

	// READ - Get all Owners
	@GetMapping
	public ResponseEntity<List<OwnerResponseDTO>> getAllOwners() {
		return ResponseEntity.ok(ownerService.getAllOwners());
	}

	// UPDATE - Update Owner
	@PutMapping("/{id}")
	public ResponseEntity<OwnerResponseDTO> updateOwner(@PathVariable Long id,
			@Valid @RequestBody OwnerRequestDTO requestDTO) {

		return ResponseEntity.ok(ownerService.updateOwner(id, requestDTO));
	}

	// DELETE - Delete Owner
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteOwner(@PathVariable Long id) {
		ownerService.deleteOwner(id);
		return ResponseEntity.ok("Owner deleted successfully");
	}
}