package com.pg_accommodation.controllers;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.pg_accommodation.dtos.reponseDtos.PGAccommodationResponseDTO;
import com.pg_accommodation.dtos.requestDtos.PGAccommodationRequestDTO;
import com.pg_accommodation.services.PGAccommodationService;

import java.util.List;

@RestController
@RequestMapping("/pg")
public class PGAccommodationController {
	@Autowired
	private PGAccommodationService pgAccommodationService;

	// CREATE - Add new PG
	@PostMapping("/add")
	public ResponseEntity<PGAccommodationResponseDTO> addPG(@Valid @RequestBody PGAccommodationRequestDTO requestDTO) {

		PGAccommodationResponseDTO response = pgAccommodationService.addPG(requestDTO);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	// READ - Get PG by ID
	@GetMapping("/details/{id}")
	public ResponseEntity<PGAccommodationResponseDTO> getPGById(@PathVariable Long id) {

		return ResponseEntity.ok(pgAccommodationService.getPGById(id));
	}

	// READ - Get available PGs by City
	@GetMapping("/city/{city}")
	public ResponseEntity<List<PGAccommodationResponseDTO>> getPGsByCity(@PathVariable String city) {

		return ResponseEntity.ok(pgAccommodationService.getPGsByCity(city));
	}

	// READ - Get available PGs by Locality
	@GetMapping("/locality/{locality}")
	public ResponseEntity<List<PGAccommodationResponseDTO>> getPGsByLocality(@PathVariable String locality) {

		return ResponseEntity.ok(pgAccommodationService.getPGsByLocality(locality));
	}

	// UPDATE - Update PG details
	@PutMapping("/{id}")
	public ResponseEntity<PGAccommodationResponseDTO> updatePG(@PathVariable Long id,
			@Valid @RequestBody PGAccommodationRequestDTO requestDTO) {

		return ResponseEntity.ok(pgAccommodationService.updatePG(id, requestDTO));
	}

	// PATCH - Change availability status
	@PatchMapping("/status/{id}")
	public ResponseEntity<String> changeAvailabilityStatus(@PathVariable Long id) {

		pgAccommodationService.changeAvailabilityStatus(id);
		return ResponseEntity.ok("PG availability status updated");
	}

	// DELETE - Delete PG
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deletePG(@PathVariable Long id) {

		pgAccommodationService.deletePG(id);
		return ResponseEntity.ok("PG deleted successfully");
	}
}