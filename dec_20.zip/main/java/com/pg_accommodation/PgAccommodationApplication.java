package com.pg_accommodation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PgAccommodationApplication {

	public static void main(String[] args) {
		SpringApplication.run(PgAccommodationApplication.class, args);
		System.out.println("PG ACCOMMODATION");
	}

}
