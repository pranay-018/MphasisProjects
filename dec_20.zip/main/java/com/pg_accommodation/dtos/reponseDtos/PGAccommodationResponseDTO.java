package com.pg_accommodation.dtos.reponseDtos;

public class PGAccommodationResponseDTO {

	private Long pgId;
	private String registrationNumber;
	private double builtUpArea;
	private double rentAmount;
	private String city;
	private String locality;
	private String availabilityStatus;
	private int visitorCount;

	public PGAccommodationResponseDTO(Long pgId, String registrationNumber, double builtUpArea, double rentAmount,
			String city, String locality, String availabilityStatus, int visitorCount) {
		super();
		this.pgId = pgId;
		this.registrationNumber = registrationNumber;
		this.builtUpArea = builtUpArea;
		this.rentAmount = rentAmount;
		this.city = city;
		this.locality = locality;
		this.availabilityStatus = availabilityStatus;
		this.visitorCount = visitorCount;
	}

	public Long getPgId() {
		return pgId;
	}

	public void setPgId(Long pgId) {
		this.pgId = pgId;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public double getBuiltUpArea() {
		return builtUpArea;
	}

	public void setBuiltUpArea(double builtUpArea) {
		this.builtUpArea = builtUpArea;
	}

	public double getRentAmount() {
		return rentAmount;
	}

	public void setRentAmount(double rentAmount) {
		this.rentAmount = rentAmount;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getAvailabilityStatus() {
		return availabilityStatus;
	}

	public void setAvailabilityStatus(String availabilityStatus) {
		this.availabilityStatus = availabilityStatus;
	}

	public int getVisitorCount() {
		return visitorCount;
	}

	public void setVisitorCount(int visitorCount) {
		this.visitorCount = visitorCount;
	}
}
