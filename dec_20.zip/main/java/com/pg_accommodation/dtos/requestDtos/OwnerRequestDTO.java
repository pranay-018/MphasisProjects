package com.pg_accommodation.dtos.requestDtos;

import jakarta.validation.constraints.*;

public class OwnerRequestDTO {

	@NotBlank(message = "Owner name is required")
	private String name;

	@Email(message = "Invalid email format")
	@NotBlank(message = "Email is required")
	private String email;

	@Pattern(regexp = "^[6-9][0-9]{9}$", message = "Mobile number must be 10 digits")
	private String mobile;

	@Min(value = 18, message = "Owner must be at least 18 years old")
	private int age;

	public OwnerRequestDTO(@NotBlank(message = "Owner name is required") String name,
			@Email(message = "Invalid email format") @NotBlank(message = "Email is required") String email,
			@Pattern(regexp = "^[6-9][0-9]{9}$", message = "Mobile number must be 10 digits") String mobile,
			@Min(value = 18, message = "Owner must be at least 18 years old") int age) {
		super();
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
}
