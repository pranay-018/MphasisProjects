package com.pg_accommodation.enums;

public enum AvailabilityStatus {
	AVAILABLE,
	OCCUPIED
}
