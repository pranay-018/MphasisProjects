package com.pg_accommodation.services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pg_accommodation.dtos.reponseDtos.PGAccommodationResponseDTO;
import com.pg_accommodation.dtos.requestDtos.PGAccommodationRequestDTO;
import com.pg_accommodation.entities.Owner;
import com.pg_accommodation.entities.PGAccommodation;
import com.pg_accommodation.enums.AvailabilityStatus;
import com.pg_accommodation.repositories.OwnerRepository;
import com.pg_accommodation.repositories.PGAccommodationRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PGAccommodationServiceImpl implements PGAccommodationService {
	@Autowired
	private  PGAccommodationRepository pgAccommodationRepository;
	@Autowired
	private OwnerRepository ownerRepository;
	
	@Override
	public PGAccommodationResponseDTO addPG(PGAccommodationRequestDTO dto) {

		Owner owner = ownerRepository.findById(dto.getOwnerId())
				.orElseThrow(() -> new RuntimeException("Owner not found"));

		PGAccommodation pg = new PGAccommodation();
		pg.setRegistrationNumber(dto.getRegistrationNumber());
		pg.setBuiltUpArea(dto.getBuiltUpArea());
		pg.setRentAmount(dto.getRentAmount());
		pg.setCity(dto.getCity());
		pg.setLocality(dto.getLocality());
		pg.setAvailabilityStatus(AvailabilityStatus.AVAILABLE);
		pg.setVisitorCount(0);
		pg.setOwner(owner);

		return mapToResponse(pgAccommodationRepository.save(pg));
	}

	// READ by ID
	@Override
	public PGAccommodationResponseDTO getPGById(Long pgId) {

		PGAccommodation pg = pgAccommodationRepository.findById(pgId)
				.orElseThrow(() -> new RuntimeException("PG Accommodation not found"));

		pg.setVisitorCount(pg.getVisitorCount() + 1);
		pgAccommodationRepository.save(pg);

		return mapToResponse(pg);
	}

	// READ by city
	@Override
	public List<PGAccommodationResponseDTO> getPGsByCity(String city) {

		return pgAccommodationRepository.findByCityIgnoreCaseAndAvailabilityStatus(city, AvailabilityStatus.AVAILABLE)
				.stream().map(this::mapToResponse).collect(Collectors.toList());
	}

	// READ by locality
	@Override
	public List<PGAccommodationResponseDTO> getPGsByLocality(String locality) {

		return pgAccommodationRepository
				.findByLocalityIgnoreCaseAndAvailabilityStatus(locality, AvailabilityStatus.AVAILABLE).stream()
				.map(this::mapToResponse).collect(Collectors.toList());
	}


	// UPDATE
	@Override
	public PGAccommodationResponseDTO updatePG(Long pgId, PGAccommodationRequestDTO dto) {

		PGAccommodation pg = pgAccommodationRepository.findById(pgId)
				.orElseThrow(() -> new RuntimeException("PG Accommodation not found"));

		pg.setRegistrationNumber(dto.getRegistrationNumber());
		pg.setBuiltUpArea(dto.getBuiltUpArea());
		pg.setRentAmount(dto.getRentAmount());
		pg.setCity(dto.getCity());
		pg.setLocality(dto.getLocality());

		return mapToResponse(pgAccommodationRepository.save(pg));
	}

	// CHANGE STATUS
	@Override
	public void changeAvailabilityStatus(Long pgId) {

		PGAccommodation pg = pgAccommodationRepository.findById(pgId)
				.orElseThrow(() -> new RuntimeException("PG Accommodation not found"));

		pg.setAvailabilityStatus(
				pg.getAvailabilityStatus() == AvailabilityStatus.AVAILABLE ? AvailabilityStatus.OCCUPIED
						: AvailabilityStatus.AVAILABLE);

		pgAccommodationRepository.save(pg);
	}

	// DELETE
	@Override
	public void deletePG(Long pgId) {

		PGAccommodation pg = pgAccommodationRepository.findById(pgId)
				.orElseThrow(() -> new RuntimeException("PG Accommodation not found"));

		pgAccommodationRepository.delete(pg);
	}

	// 🔁 Mapper method
	private PGAccommodationResponseDTO mapToResponse(PGAccommodation pg) {

		return new PGAccommodationResponseDTO(pg.getPgId(), pg.getRegistrationNumber(), pg.getBuiltUpArea(),
				pg.getRentAmount(), pg.getCity(), pg.getLocality(), pg.getAvailabilityStatus().name(),
				pg.getVisitorCount());
	}
}
