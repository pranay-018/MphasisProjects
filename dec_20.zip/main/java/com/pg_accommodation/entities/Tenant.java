package com.pg_accommodation.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name = "tenants")
public class Tenant {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long tenantId;
	@NotBlank(message = "Tenant Name is required")
	@NotNull(message = "Tenant Name cannot be null")
	private String name;
	@Email(message = "Email must in appropriate format")
	@Column(unique = true)
	@NotBlank(message = "Email is required")
	private String email;
	@Pattern(regexp = "^[6-9][0-9]{9}$", message = "mobile number must be 10 digits")
	@Column(unique = true)
	private String mobileNumber;
	@Min(value = 18, message = "Tenant must be at least 18 years old")
	private int age;
	@NotBlank(message = "Gender is required")
	private String gender;

	public Long getTenantId() {
		return tenantId;
	}

	public void setTenantId(Long tenantId) {
		this.tenantId = tenantId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Tenant{" + "tenantId=" + tenantId + ", name='" + name + '\'' + ", email='" + email + '\''
				+ ", mobileNumber='" + mobileNumber + '\'' + ", age=" + age + ", gender='" + gender + '\'' + '}';
	}

}
