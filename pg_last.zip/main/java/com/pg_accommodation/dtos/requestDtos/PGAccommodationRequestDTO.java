package com.pg_accommodation.dtos.requestDtos;

import jakarta.validation.constraints.*;

public class PGAccommodationRequestDTO {

	@NotBlank(message = "Registration number is required")
	private String registrationNumber;

	@Positive(message = "Built-up area must be positive")
	private double builtUpArea;

	@Positive(message = "Rent amount must be positive")
	private double rentAmount;

	@NotBlank(message = "City is required")
	private String city;

	@NotBlank(message = "Locality is required")
	private String locality;

	@NotNull(message = "Owner ID is required")
	private Long ownerId;

	public PGAccommodationRequestDTO(@NotBlank(message = "Registration number is required") String registrationNumber,
			@Positive(message = "Built-up area must be positive") double builtUpArea,
			@Positive(message = "Rent amount must be positive") double rentAmount,
			@NotBlank(message = "City is required") String city,
			@NotBlank(message = "Locality is required") String locality,
			@NotNull(message = "Owner ID is required") Long ownerId) {
		super();
		this.registrationNumber = registrationNumber;
		this.builtUpArea = builtUpArea;
		this.rentAmount = rentAmount;
		this.city = city;
		this.locality = locality;
		this.ownerId = ownerId;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public double getBuiltUpArea() {
		return builtUpArea;
	}

	public void setBuiltUpArea(double builtUpArea) {
		this.builtUpArea = builtUpArea;
	}

	public double getRentAmount() {
		return rentAmount;
	}

	public void setRentAmount(double rentAmount) {
		this.rentAmount = rentAmount;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public Long getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(Long ownerId) {
		this.ownerId = ownerId;
	}
}
