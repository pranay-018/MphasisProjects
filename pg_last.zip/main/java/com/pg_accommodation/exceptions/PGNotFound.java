package com.pg_accommodation.exceptions;

public class PGNotFound extends RuntimeException {
	public PGNotFound(String message) {
		super(message);
	}
}