package com.pg_accommodation.exceptions;

public class TenantNotFound extends RuntimeException {
	public TenantNotFound(String message) {
		super(message);
	}
}
