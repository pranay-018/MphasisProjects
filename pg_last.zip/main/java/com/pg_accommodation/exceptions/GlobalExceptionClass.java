package com.pg_accommodation.exceptions;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionClass {
	@ExceptionHandler(TenantNotFound.class)
	public ResponseEntity<String> handleTenantNotFound(TenantNotFound e) {
		return new ResponseEntity<>("exception occured : "+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	@ExceptionHandler(OwnerNotFound.class)
	public ResponseEntity<String> handleOwnerNotFound(OwnerNotFound e) {
		return new ResponseEntity<>("exception occured : "+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	@ExceptionHandler(PGNotFound.class)
	public ResponseEntity<String> handlePGNotFound(PGNotFound e) {
		return new ResponseEntity<>("exception occured : "+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	@ExceptionHandler(EmailAlreadyExisting.class)
	public ResponseEntity<String> handleEmailAlreadyExisting(EmailAlreadyExisting e) {
		return new ResponseEntity<>("exception occured : "+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	@ExceptionHandler(MobileNumberAlreadyExists.class)
	public ResponseEntity<String> handleMobileNumberAlreadyExists(MobileNumberAlreadyExists e) {
		return new ResponseEntity<>("exception occured : "+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleException(Exception e) {
		return new ResponseEntity<>("exception occured : "+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
}

