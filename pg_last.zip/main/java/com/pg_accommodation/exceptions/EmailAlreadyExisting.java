package com.pg_accommodation.exceptions;

public class EmailAlreadyExisting extends RuntimeException {
	public EmailAlreadyExisting(String message) {
		super(message);
	}
}