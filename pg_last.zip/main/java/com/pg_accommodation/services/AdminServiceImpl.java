package com.pg_accommodation.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pg_accommodation.dtos.reponseDtos.OwnerResponseDTO;
import com.pg_accommodation.dtos.reponseDtos.PGAccommodationResponseDTO;
import com.pg_accommodation.dtos.reponseDtos.TenantResponseDTO;
import com.pg_accommodation.entities.Owner;
import com.pg_accommodation.entities.PGAccommodation;
import com.pg_accommodation.entities.Tenant;
import com.pg_accommodation.repositories.OwnerRepository;
import com.pg_accommodation.repositories.PGAccommodationRepository;
import com.pg_accommodation.repositories.TenantRepository;
import com.pg_accommodation.services.AdminService;

@Service
public class AdminServiceImpl implements AdminService {
	@Autowired
	private TenantRepository tenantRepository;
	@Autowired
	private OwnerRepository ownerRepository;
	@Autowired
	private PGAccommodationRepository pgRepository;

	@Override
    public List<TenantResponseDTO> getAllTenants() {
		 return tenantRepository.findAll()
		            .stream()
		            .map(t -> new TenantResponseDTO(
		                    t.getTenantId(),
		                    t.getName(),
		                    t.getEmail(),
		                    t.getMobileNumber(),
		                    t.getAge(),
		                    t.getGender()
		            ))
		            .collect(Collectors.toList());
    }

	@Override
	public List<OwnerResponseDTO> getAllOwners() {
		return ownerRepository.findAll().stream()
				.map(o -> new OwnerResponseDTO(o.getOwnerId(), o.getName(), o.getEmail(), o.getMobile(), o.getAge()))
				.collect(Collectors.toList());
	}

	@Override
	public List<PGAccommodationResponseDTO> getAllPGs() {
		return pgRepository.findAll().stream()
				.map(pg -> new PGAccommodationResponseDTO(pg.getPgId(), pg.getRegistrationNumber(), pg.getBuiltUpArea(),
						pg.getRentAmount(), pg.getCity(), pg.getLocality(), pg.getAvailabilityStatus().name(),
						pg.getVisitorCount()))
				.collect(Collectors.toList());
	}

	@Override
	public void deleteTenant(Long tenantId) {
		Tenant tenant = tenantRepository.findById(tenantId).orElseThrow(() -> new RuntimeException("Tenant not found"));
		tenantRepository.delete(tenant);
	}

	@Override
	public void deleteOwner(Long ownerId) {
		Owner owner = ownerRepository.findById(ownerId).orElseThrow(() -> new RuntimeException("Owner not found"));
		ownerRepository.delete(owner);
	}

	@Override
	public void deletePG(Long pgId) {
		PGAccommodation pg = pgRepository.findById(pgId).orElseThrow(() -> new RuntimeException("PG not found"));
		pgRepository.delete(pg);
	}
}
