package com.pg_accommodation.controllers;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.pg_accommodation.dtos.reponseDtos.OwnerResponseDTO;
import com.pg_accommodation.dtos.reponseDtos.PGAccommodationResponseDTO;
import com.pg_accommodation.dtos.requestDtos.OwnerRequestDTO;
import com.pg_accommodation.dtos.requestDtos.PGAccommodationRequestDTO;
import com.pg_accommodation.services.OwnerService;
import com.pg_accommodation.services.PGAccommodationService;

import java.util.List;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/owners")
@Tag(name = "Owner APIs", description = "Owner related operations")
public class OwnerController {

    @Autowired
    private OwnerService ownerService;
    @Autowired
    private PGAccommodationService pgAccommodationService;

    @Operation(summary = "Register a new owner")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Owner registered successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid owner data")
    })
    @PostMapping("/register")
    public ResponseEntity<OwnerResponseDTO> registerOwner(
            @Valid @RequestBody OwnerRequestDTO requestDTO) {

        OwnerResponseDTO response = ownerService.registerOwner(requestDTO);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @Operation(summary = "Get owner by ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Owner found"),
        @ApiResponse(responseCode = "404", description = "Owner not found")
    })
    @GetMapping("/{id}")
    public ResponseEntity<OwnerResponseDTO> getOwnerById(@PathVariable Long id) {
        return ResponseEntity.ok(ownerService.getOwnerById(id));
    }

    @Operation(summary = "Update owner details")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Owner updated successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid owner data"),
        @ApiResponse(responseCode = "404", description = "Owner not found")
    })
    @PutMapping("/{id}")
    public ResponseEntity<OwnerResponseDTO> updateOwner(
            @PathVariable Long id,
            @Valid @RequestBody OwnerRequestDTO requestDTO) {

        return ResponseEntity.ok(ownerService.updateOwner(id, requestDTO));
    }

    @Operation(summary = "Delete owner")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Owner deleted successfully"),
        @ApiResponse(responseCode = "404", description = "Owner not found")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteOwner(@PathVariable Long id) {

        ownerService.deleteOwner(id);
        return ResponseEntity.ok("Owner deleted successfully");
    }
    
    @Operation(summary = "Add a new PG accommodation")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "PG added successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid PG data")
    })
    @PostMapping("/add")
    public ResponseEntity<PGAccommodationResponseDTO> addPG(
            @Valid @RequestBody PGAccommodationRequestDTO requestDTO) {

        PGAccommodationResponseDTO response = pgAccommodationService.addPG(requestDTO);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
    @Operation(summary = "Change PG availability status")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "PG status updated successfully"),
        @ApiResponse(responseCode = "404", description = "PG not found")
    })
    @PatchMapping("/status/{id}")
    public ResponseEntity<String> changeAvailabilityStatus(@PathVariable Long id) {

        pgAccommodationService.changeAvailabilityStatus(id);
        return ResponseEntity.ok("PG availability status updated");
    }
    @Operation(summary = "Update PG accommodation details")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "PG updated successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid PG data"),
        @ApiResponse(responseCode = "404", description = "PG not found")
    })
    @PutMapping("/pg_update/{id}")
    public ResponseEntity<PGAccommodationResponseDTO> updatePG(
            @PathVariable Long id,
            @Valid @RequestBody PGAccommodationRequestDTO requestDTO) {

        return ResponseEntity.ok(pgAccommodationService.updatePG(id, requestDTO));
    }
    
    @Operation(summary = "Delete PG accommodation")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "PG deleted successfully"),
        @ApiResponse(responseCode = "404", description = "PG not found")
    })
    @DeleteMapping("/pg_delete/{id}")
    public ResponseEntity<String> deletePG(@PathVariable Long id) {

        pgAccommodationService.deletePG(id);
        return ResponseEntity.ok("PG deleted successfully");
    }
    
    

}
