package com.pg_accommodation.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.pg_accommodation.dtos.reponseDtos.PGAccommodationResponseDTO;
import com.pg_accommodation.dtos.reponseDtos.TenantResponseDTO;
import com.pg_accommodation.dtos.requestDtos.TenantRequestDTO;
import com.pg_accommodation.services.PGAccommodationService;
import com.pg_accommodation.services.TenantService;

import jakarta.validation.Valid;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/tenants")
@Tag(name = "Tenant APIs", description = "Tenant related operations")
public class TenantController {

	@Autowired
	private TenantService tenantService;
	@Autowired
	private PGAccommodationService pgAccommodationService;

	@Operation(summary = "Register a new tenant")
	@ApiResponses({ @ApiResponse(responseCode = "201", description = "Tenant registered successfully"),
			@ApiResponse(responseCode = "400", description = "Invalid tenant data") })
	@PostMapping("/register")
	public ResponseEntity<TenantResponseDTO> registerTenant(@Valid @RequestBody TenantRequestDTO requestDTO) {

		TenantResponseDTO response = tenantService.registerTenant(requestDTO);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@Operation(summary = "Get tenant by ID")
	@ApiResponses({ @ApiResponse(responseCode = "200", description = "Tenant found"),
			@ApiResponse(responseCode = "404", description = "Tenant not found") })
	@GetMapping("/{id}")
	public ResponseEntity<TenantResponseDTO> getTenantById(@PathVariable Long id) {

		return ResponseEntity.ok(tenantService.getTenantById(id));
	}

	@Operation(summary = "Update tenant details")
	@ApiResponses({ @ApiResponse(responseCode = "200", description = "Tenant updated successfully"),
			@ApiResponse(responseCode = "400", description = "Invalid tenant data"),
			@ApiResponse(responseCode = "404", description = "Tenant not found") })
	@PutMapping("/{id}")
	public ResponseEntity<TenantResponseDTO> updateTenant(@PathVariable Long id,
			@Valid @RequestBody TenantRequestDTO requestDTO) {

		return ResponseEntity.ok(tenantService.updateTenant(id, requestDTO));
	}

	@Operation(summary = "Delete tenant")
	@ApiResponses({ @ApiResponse(responseCode = "200", description = "Tenant deleted successfully"),
			@ApiResponse(responseCode = "404", description = "Tenant not found") })
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteTenant(@PathVariable Long id) {

		tenantService.deleteTenant(id);
		return ResponseEntity.ok("Tenant deleted successfully");
	}

	@Operation(summary = "Get available PGs by city")
	@ApiResponses({ @ApiResponse(responseCode = "200", description = "PGs retrieved successfully") })
	@GetMapping("/city/{city}")
	public ResponseEntity<List<PGAccommodationResponseDTO>> getPGsByCity(@PathVariable String city) {

		return ResponseEntity.ok(pgAccommodationService.getPGsByCity(city));
	}
	 @Operation(summary = "Get available PGs by locality")
	    @ApiResponses({
	        @ApiResponse(responseCode = "200", description = "PGs retrieved successfully")
	    })
	    @GetMapping("/locality/{locality}")
	    public ResponseEntity<List<PGAccommodationResponseDTO>> getPGsByLocality(
	            @PathVariable String locality) {

	        return ResponseEntity.ok(pgAccommodationService.getPGsByLocality(locality));
	    }

}
